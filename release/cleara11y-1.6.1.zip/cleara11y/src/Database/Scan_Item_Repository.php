<?php
/**
 * Scan Item Repository
 *
 * Handles database operations for Scan_Item records.
 *
 * @package ClearA11y
 * @namespace ClearA11y\Database
 */

namespace ClearA11y\Database;

if (! defined('ABSPATH')) {
	exit;
}

use ClearA11y\Models\Scan_Item;

/**
 * Scan Item Repository Class
 */
class Scan_Item_Repository {

	/**
	 * Get table name.
	 *
	 * @return string
	 */
	private static function get_table(): string {
		return Schema::get_table_name('scan_items');
	}

	/**
	 * Insert a new scan item.
	 *
	 * @param Scan_Item $item Scan Item object.
	 * @return int|false Inserted ID or false on failure.
	 */
	public static function insert(Scan_Item $item): int|false {
		global $wpdb;

		$data = [
			'scan_id' => $item->scan_id,
			'post_id' => $item->post_id,
			'post_type' => $item->post_type,
			'post_title' => $item->post_title,
			'post_url' => $item->post_url,
			'status' => $item->status,
			'scan_method' => $item->scan_method,
			'total_issues' => $item->total_issues,
			'critical_issues' => $item->critical_issues,
			'moderate_issues' => $item->moderate_issues,
			'minor_issues' => $item->minor_issues,
			'error_message' => $item->error_message,
			'scanned_at' => $item->scanned_at,
			'created_at' => $item->created_at ?: current_time('mysql', true),
			// Scoring fields
			'rules_checked' => $item->rules_checked ?? 0,
			'rules_passed' => $item->rules_passed ?? 0,
			'rules_failed' => $item->rules_failed ?? 0,
			'rules_incomplete' => $item->rules_incomplete ?? 0,
			'pass_percentage' => $item->pass_percentage ?? 0.0,
			'fail_percentage' => $item->fail_percentage ?? 0.0,
			'score_grade' => $item->score_grade ?? null,
			'rules_checked_list' => $item->rules_checked_list ?? null,
			'rules_passed_list' => $item->rules_passed_list ?? null,
			'rules_failed_list' => $item->rules_failed_list ?? null,
			'rules_incomplete_list' => $item->rules_incomplete_list ?? null,
		];

		$format = ['%d', '%d', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%d', '%d', '%s', '%s', '%s',
			// Scoring format
			'%d', '%d', '%d', '%d', '%f', '%f', '%s', '%s', '%s', '%s', '%s',
		];

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery -- Write to plugin-owned tables; no WordPress data API or cached result applies.
		$result = $wpdb->insert(
			self::get_table(),
			$data,
			$format
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery

		return $result ? $wpdb->insert_id : false;
	}

	/**
	 * Update an existing scan item.
	 *
	 * @param Scan_Item $item Scan Item object.
	 * @return bool True on success, false on failure.
	 */
	public static function update(Scan_Item $item): bool {
		global $wpdb;

		$data = [
			'status' => $item->status,
			'scan_method' => $item->scan_method,
			'total_issues' => $item->total_issues,
			'critical_issues' => $item->critical_issues,
			'moderate_issues' => $item->moderate_issues,
			'minor_issues' => $item->minor_issues,
			'error_message' => $item->error_message,
			'scanned_at' => $item->scanned_at,
			// Scoring fields
			'rules_checked' => $item->rules_checked ?? 0,
			'rules_passed' => $item->rules_passed ?? 0,
			'rules_failed' => $item->rules_failed ?? 0,
			'rules_incomplete' => $item->rules_incomplete ?? 0,
			'pass_percentage' => $item->pass_percentage ?? 0.0,
			'fail_percentage' => $item->fail_percentage ?? 0.0,
			'score_grade' => $item->score_grade ?? null,
			'rules_checked_list' => $item->rules_checked_list ?? null,
			'rules_passed_list' => $item->rules_passed_list ?? null,
			'rules_failed_list' => $item->rules_failed_list ?? null,
			'rules_incomplete_list' => $item->rules_incomplete_list ?? null,
		];

		$format = ['%s', '%s', '%d', '%d', '%d', '%d', '%s', '%s',
			// Scoring format
			'%d', '%d', '%d', '%d', '%f', '%f', '%s', '%s', '%s', '%s', '%s',
		];

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Write to plugin-owned tables; no WordPress data API or cached result applies.
		$result = $wpdb->update(
			self::get_table(),
			$data,
			['id' => $item->id],
			$format,
			['%d']
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $result !== false;
	}

	/**
	 * Get scan item by ID.
	 *
	 * @param int $item_id Scan Item ID.
	 * @return Scan_Item|null
	 */
	public static function get_by_id(int $item_id): ?Scan_Item {
		global $wpdb;

		$table = self::get_table();
		// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state; Schema-owned identifiers and fixed SQL fragments; variable values are prepared separately.
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM `{$table}` WHERE id = %d",
				$item_id
			)
		);
		// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return $row ? Scan_Item::from_row($row) : null;
	}

	/**
	 * Get all scan items for a scan.
	 *
	 * @param int   $scan_id Scan ID.
	 * @param array $args    Optional query arguments.
	 * @return Scan_Item[]
	 */
	public static function get_by_scan_id(int $scan_id, array $args = []): array {
		global $wpdb;

		$defaults = [
			'status' => null,
			'orderby' => 'created_at',
			'order' => 'ASC',
			'limit' => null,
			'offset' => 0,
		];

		$args = wp_parse_args($args, $defaults);

		$where = ['scan_id = %d'];
		$where_params = [$scan_id];

		if (!empty($args['status'])) {
			$where[] = 'status = %s';
			$where_params[] = $args['status'];
		}

		$where_clause = implode(' AND ', $where);
		$allowed_orderby = [
			'id' => 'id',
			'post_title' => 'post_title',
			'status' => 'status',
			'total_issues' => 'total_issues',
			'created_at' => 'created_at',
			'scanned_at' => 'scanned_at',
		];
		$orderby_field = $allowed_orderby[$args['orderby']] ?? 'created_at';
		$order = strtoupper((string) $args['order']) === 'DESC' ? 'DESC' : 'ASC';
		$orderby = sanitize_sql_orderby("{$orderby_field} {$order}");

		$table = self::get_table();
		$limit_clause = '';
		if (null !== $args['limit']) {
			$limit = max(1, absint($args['limit']));
			$offset = max(0, absint($args['offset']));
			$limit_clause = $wpdb->prepare(' LIMIT %d OFFSET %d', $limit, $offset);
		}
		// @phpstan-ignore-next-line
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- Fixed filter/IN fragments contain placeholders populated by the matching parameter list.
		$query = $wpdb->prepare(
			"SELECT * FROM `{$table}` WHERE {$where_clause} ORDER BY {$orderby}{$limit_clause}",
			...$where_params
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare

		$rows = $wpdb->get_results($query); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state.

		return array_map(fn($row) => Scan_Item::from_row($row), $rows ?: []);
	}

	/**
	 * Get scan item by scan ID and post ID.
	 *
	 * @param int $scan_id Scan ID.
	 * @param int $post_id Post ID.
	 * @return Scan_Item|null
	 */
	public static function get_by_scan_and_post(int $scan_id, int $post_id): ?Scan_Item {
		global $wpdb;

		$table = self::get_table();
		// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state; Schema-owned identifiers and fixed SQL fragments; variable values are prepared separately.
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM `{$table}` WHERE scan_id = %d AND post_id = %d",
				$scan_id,
				$post_id
			)
		);
		// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return $row ? Scan_Item::from_row($row) : null;
	}

	/**
	 * Delete scan item by ID.
	 *
	 * @param int $item_id Scan Item ID.
	 * @return bool True on success, false on failure.
	 */
	public static function delete(int $item_id): bool {
		global $wpdb;

		// Also delete related issues
		Issue_Repository::delete_by_scan_item_id($item_id);

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Write to plugin-owned tables; no WordPress data API or cached result applies.
		$result = $wpdb->delete(
			self::get_table(),
			['id' => $item_id],
			['%d']
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $result !== false;
	}

	/**
	 * Delete all scan items for a scan.
	 *
	 * @param int $scan_id Scan ID.
	 * @return int Number of items deleted.
	 */
	public static function delete_by_scan_id(int $scan_id): int {
		global $wpdb;
		$table = self::get_table();

		// Get item IDs to delete their issues first
		// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state; Schema-owned identifiers and fixed SQL fragments; variable values are prepared separately.
		$item_ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT id FROM `{$table}` WHERE scan_id = %d",
				$scan_id
			)
		);
		// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		foreach ($item_ids as $item_id) {
			Issue_Repository::delete_by_scan_item_id((int) $item_id);
		}

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Write to plugin-owned tables; no WordPress data API or cached result applies.
		return $wpdb->delete(
			self::get_table(),
			['scan_id' => $scan_id],
			['%d']
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/**
	 * Update scan item status.
	 *
	 * @param int    $item_id Scan Item ID.
	 * @param string $status  New status.
	 * @return bool True on success, false on failure.
	 */
	public static function update_status(int $item_id, string $status): bool {
		global $wpdb;

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Write to plugin-owned tables; no WordPress data API or cached result applies.
		$result = $wpdb->update(
			self::get_table(),
			['status' => $status],
			['id' => $item_id],
			['%s'],
			['%d']
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $result !== false;
	}

	/**
	 * Reset in-progress items for one scan so they can be retried.
	 *
	 * @param int $scan_id Scan ID.
	 * @return int|false Number of reset items, or false on failure.
	 */
	public static function reset_in_progress_by_scan_id(int $scan_id): int|false {
		global $wpdb;
		$table = self::get_table();

		// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Write to plugin-owned tables; no WordPress data API or cached result applies; Schema-owned identifiers and fixed SQL fragments; variable values are prepared separately.
		return $wpdb->query(
			$wpdb->prepare(
				"UPDATE `{$table}`
				SET status = 'pending', error_message = %s
				WHERE scan_id = %d AND status = 'in_progress'",
				__('Reset by an administrator after the worker stopped responding.', 'cleara11y'),
				$scan_id
			)
		);
		// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * Cancel unfinished items for one scan.
	 *
	 * @param int    $scan_id Scan ID.
	 * @param string $reason  Cancellation reason.
	 * @return int|false Number of cancelled items, or false on failure.
	 */
	public static function cancel_incomplete_by_scan_id(int $scan_id, string $reason): int|false {
		global $wpdb;
		$table = self::get_table();

		// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Write to plugin-owned tables; no WordPress data API or cached result applies; Schema-owned identifiers and fixed SQL fragments; variable values are prepared separately.
		return $wpdb->query(
			$wpdb->prepare(
				"UPDATE `{$table}`
				SET status = 'cancelled', error_message = %s
				WHERE scan_id = %d AND status IN ('pending', 'in_progress')",
				$reason,
				$scan_id
			)
		);
		// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * Get count of scan items by status for a scan.
	 *
	 * @param int         $scan_id Scan ID.
	 * @param string|null $status  Status to filter by, or null for all.
	 * @return int
	 */
	public static function get_count(int $scan_id, ?string $status = null): int {
		global $wpdb;

		$where = ['scan_id = %d'];
		$params = [$scan_id];

		if ($status) {
			$where[] = 'status = %s';
			$params[] = $status;
		}

		$where_clause = implode(' AND ', $where);

		$table = self::get_table();
		// @phpstan-ignore-next-line
		// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- Live scan/exception state in custom tables; caching can return stale worker or suppression state; Fixed filter/IN fragments contain placeholders populated by the matching parameter list.
		$count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM `{$table}` WHERE {$where_clause}",
				...$params
			)
		);
		// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare

		return (int) $count;
	}

	/**
	 * Get pending scan items for batch processing.
	 *
	 * @param int $scan_id Scan ID.
	 * @param int $limit   Number of items to return.
	 * @return Scan_Item[]
	 */
	public static function get_pending_batch(int $scan_id, int $limit = 20): array {
		return self::get_by_scan_id(
			$scan_id,
			[
				'status' => 'pending',
				'orderby' => 'created_at',
				'order' => 'ASC',
				'limit' => $limit,
			]
		);
	}

	/**
	 * Create scan items for a scan from post IDs.
	 *
	 * @param int   $scan_id  Scan ID.
	 * @param array $post_ids Array of post IDs.
	 * @return bool True on success, false on failure.
	 */
	public static function create_from_posts(int $scan_id, array $post_ids): bool {
		foreach ($post_ids as $post_id) {
			$post = get_post($post_id);

			if (!$post || $post->post_status !== 'publish') {
				continue;
			}

			$item = new Scan_Item();
			$item->scan_id = $scan_id;
			$item->post_id = $post_id;
			$item->post_type = $post->post_type;
			$item->post_title = $post->post_title;
			$item->post_url = get_permalink($post_id);
			$item->status = 'pending';
			$item->scan_method = 'client';
			$item->created_at = current_time('mysql', true);

			self::insert($item);
		}

		return true;
	}
}
