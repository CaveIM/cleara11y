<?php
/**
 * Database Schema
 *
 * Handles creation and management of custom database tables.
 *
 * @package ClearA11y
 * @namespace ClearA11y\Database
 */

namespace ClearA11y\Database;

if (! defined('ABSPATH')) {
	exit;
}

/**
 * Schema Class
 */
class Schema {

	/**
	 * Get table prefix.
	 *
	 * @return string
	 */
	private static function get_prefix(): string {
		global $wpdb;
		return $wpdb->prefix . 'cleara11y_';
	}

	/**
	 * Get full table name.
	 *
	 * @param string $table Table name without prefix.
	 * @return string
	 */
	public static function get_table_name(string $table): string {
		return self::get_prefix() . $table;
	}

	/**
	 * Create all custom tables.
	 *
	 * @return bool True if successful.
	 */
	public static function create_tables(): bool {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();
		$prefix = self::get_prefix();

		$queries = [];

		// 1. Scans table - Main scan records
		$queries[] = "CREATE TABLE IF NOT EXISTS `{$prefix}scans` (
			`id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			`scan_type` varchar(20) NOT NULL DEFAULT 'individual',
			`scan_name` varchar(255) DEFAULT NULL,
			`status` varchar(20) NOT NULL DEFAULT 'pending',
			`total_items` int(11) NOT NULL DEFAULT 0,
			`scanned_items` int(11) NOT NULL DEFAULT 0,
			`total_issues` int(11) NOT NULL DEFAULT 0,
			`critical_issues` int(11) NOT NULL DEFAULT 0,
			`moderate_issues` int(11) NOT NULL DEFAULT 0,
			`minor_issues` int(11) NOT NULL DEFAULT 0,
			`started_at` datetime DEFAULT NULL,
			`completed_at` datetime DEFAULT NULL,
			`created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			`updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY (`id`),
			KEY `scan_type` (`scan_type`),
			KEY `status` (`status`),
			KEY `created_at` (`created_at`)
		) $charset_collate;";

		// 2. Scan Items table - Individual page scans linked to scans
		$queries[] = "CREATE TABLE IF NOT EXISTS `{$prefix}scan_items` (
			`id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			`scan_id` bigint(20) UNSIGNED NOT NULL,
			`post_id` bigint(20) UNSIGNED NOT NULL,
			`post_type` varchar(20) NOT NULL,
			`post_title` varchar(255) DEFAULT NULL,
			`post_url` varchar(255) NOT NULL,
			`status` varchar(20) NOT NULL DEFAULT 'pending',
			`scan_method` varchar(20) NOT NULL DEFAULT 'client',
			`total_issues` int(11) NOT NULL DEFAULT 0,
			`critical_issues` int(11) NOT NULL DEFAULT 0,
			`moderate_issues` int(11) NOT NULL DEFAULT 0,
			`minor_issues` int(11) NOT NULL DEFAULT 0,
			`error_message` text DEFAULT NULL,
			`scanned_at` datetime DEFAULT NULL,
			`rules_checked` int(11) NOT NULL DEFAULT 0,
			`rules_passed` int(11) NOT NULL DEFAULT 0,
			`rules_failed` int(11) NOT NULL DEFAULT 0,
			`rules_incomplete` int(11) NOT NULL DEFAULT 0,
			`pass_percentage` decimal(5,2) NOT NULL DEFAULT 0.00,
			`fail_percentage` decimal(5,2) NOT NULL DEFAULT 0.00,
			`score_grade` varchar(1) DEFAULT NULL,
			`rules_checked_list` longtext DEFAULT NULL,
			`rules_passed_list` longtext DEFAULT NULL,
			`rules_failed_list` longtext DEFAULT NULL,
			`rules_incomplete_list` longtext DEFAULT NULL,
			`template` varchar(255) DEFAULT NULL,
			`created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (`id`),
			KEY `scan_id` (`scan_id`),
			KEY `post_id` (`post_id`),
			KEY `latest_completed_post` (`post_id`, `status`, `scanned_at`, `id`),
			KEY `status` (`status`),
			KEY `scan_method` (`scan_method`),
			KEY `pass_percentage` (`pass_percentage`),
			KEY `score_grade` (`score_grade`),
			KEY `created_at` (`created_at`)
		) $charset_collate;";

		// 3. Issues table - Individual accessibility issues
		$queries[] = "CREATE TABLE IF NOT EXISTS `{$prefix}issues` (
			`id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			`scan_id` bigint(20) UNSIGNED NOT NULL,
			`scan_item_id` bigint(20) UNSIGNED NOT NULL,
			`post_id` bigint(20) UNSIGNED NOT NULL,
			`rule_id` varchar(100) NOT NULL,
			`rule_type` varchar(20) NOT NULL,
			`result_type` varchar(20) NOT NULL DEFAULT 'violation',
			`severity` varchar(20) NOT NULL,
			`impact` varchar(20) DEFAULT NULL,
			`selector` varchar(500) DEFAULT NULL,
			`html` text DEFAULT NULL,
			`message` text DEFAULT NULL,
			`help_text` text DEFAULT NULL,
			`help_url` varchar(500) DEFAULT NULL,
			`wcag_criterion` varchar(100) DEFAULT NULL,
			`dismissed` tinyint(1) NOT NULL DEFAULT 0,
			`dismissed_by` bigint(20) UNSIGNED DEFAULT NULL,
			`dismissed_at` datetime DEFAULT NULL,
			`dismissal_comment` text DEFAULT NULL,
			`dismissed_global` tinyint(1) NOT NULL DEFAULT 0,
			`dismissed_global_by` bigint(20) UNSIGNED DEFAULT NULL,
			`dismissed_global_at` datetime DEFAULT NULL,
			`dismissed_global_comment` text DEFAULT NULL,
			`selector_score` int(11) DEFAULT NULL,
			`selector_match_count` int(11) DEFAULT NULL,
			`xpath` varchar(500) DEFAULT NULL,
			`dom_path` text DEFAULT NULL,
			`ancestor_chain` text DEFAULT NULL,
			`accessible_name` varchar(500) DEFAULT NULL,
			`inner_text_snippet` varchar(500) DEFAULT NULL,
			`bounding_box` varchar(100) DEFAULT NULL,
			`computed_style` text DEFAULT NULL,
			`fingerprint_strict` varchar(64) DEFAULT NULL,
			`fingerprint_loose` varchar(64) DEFAULT NULL,
			`signature_version` int(11) DEFAULT 1,
			`node_evidence` longtext DEFAULT NULL,
			`source_type` varchar(30) DEFAULT NULL,
			`source_ref` varchar(500) DEFAULT NULL,
			`owner_type` varchar(30) DEFAULT NULL,
			`owner_name` varchar(255) DEFAULT NULL,
			`source_key` varchar(64) DEFAULT NULL,
			`page_object_key` varchar(500) DEFAULT NULL,
			`element_identity_v2` varchar(64) DEFAULT NULL,
			`element_identity_v2_inputs` longtext DEFAULT NULL,
			`violation_identity_v2` varchar(64) DEFAULT NULL,
			`violation_identity_v2_inputs` longtext DEFAULT NULL,
			`identity_signature_version` int(11) DEFAULT NULL,
			`created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (`id`),
			KEY `scan_id` (`scan_id`),
			KEY `scan_item_id` (`scan_item_id`),
			KEY `post_id` (`post_id`),
			KEY `rule_id` (`rule_id`),
			KEY `result_type` (`result_type`),
			KEY `severity` (`severity`),
			KEY `dismissed` (`dismissed`),
			KEY `dismissed_global` (`dismissed_global`),
			KEY `fingerprint_strict` (`fingerprint_strict`),
			KEY `fingerprint_loose` (`fingerprint_loose`),
			KEY `source_key` (`source_key`),
			KEY `owner_type` (`owner_type`),
			KEY `page_object_key` (`page_object_key`(191)),
			KEY `element_identity_v2` (`element_identity_v2`),
			KEY `violation_identity_v2` (`violation_identity_v2`),
			KEY `created_at` (`created_at`),
			KEY `explorer_scan_filters` (`scan_id`, `severity`, `rule_id`, `post_id`, `id`),
			KEY `explorer_live_filters` (`scan_item_id`, `severity`, `rule_id`, `id`)
		) $charset_collate;";

		// 4. Canonical occurrence state keyed by validated v2 identity.
		$queries[] = "CREATE TABLE IF NOT EXISTS `{$prefix}occurrence_states` (
			`id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			`site_id` bigint(20) UNSIGNED NOT NULL,
			`violation_identity_v2` varchar(64) NOT NULL,
			`element_identity_v2` varchar(64) NOT NULL,
			`identity_signature_version` int(11) NOT NULL,
			`page_object_key` varchar(500) NOT NULL,
			`post_id` bigint(20) UNSIGNED NOT NULL,
			`rule_id` varchar(100) NOT NULL,
			`status` varchar(20) NOT NULL DEFAULT 'active',
			`first_seen_at` datetime NOT NULL,
			`last_seen_at` datetime NOT NULL,
			`resolved_at` datetime DEFAULT NULL,
			`reappearance_count` int(11) UNSIGNED NOT NULL DEFAULT 0,
			`latest_issue_id` bigint(20) UNSIGNED NOT NULL,
			`latest_scan_id` bigint(20) UNSIGNED NOT NULL,
			`created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			`updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY (`id`),
			UNIQUE KEY `site_violation_signature` (`site_id`, `violation_identity_v2`, `identity_signature_version`),
			KEY `active_page` (`site_id`, `status`, `page_object_key`(150)),
			KEY `latest_issue_id` (`latest_issue_id`),
			KEY `latest_scan_id` (`latest_scan_id`),
			KEY `element_identity_v2` (`element_identity_v2`)
		) $charset_collate;";


		// 5. Scan Jobs table - Job queue with leasing for parallel scanning
		$queries[] = "CREATE TABLE IF NOT EXISTS `{$prefix}scan_jobs` (
			`id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			`site_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
			`url` text NOT NULL,
			`post_id` bigint(20) UNSIGNED NOT NULL,
			`scan_id` bigint(20) UNSIGNED NOT NULL,
			`status` varchar(20) NOT NULL DEFAULT 'pending',
			`priority` int(11) NOT NULL DEFAULT 0,
			`attempts` int(11) NOT NULL DEFAULT 0,
			`lease_token` varchar(64) DEFAULT NULL,
			`lease_expires_at` datetime DEFAULT NULL,
			`last_error` text DEFAULT NULL,
			`last_started_at` datetime DEFAULT NULL,
			`last_finished_at` datetime DEFAULT NULL,
			`result_json` longtext DEFAULT NULL,
			`created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			`updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY (`id`),
			KEY `status_priority` (`status`, `priority`),
			KEY `lease_expires` (`lease_expires_at`),
			KEY `post_id` (`post_id`),
			KEY `scan_id` (`scan_id`),
			KEY `site_id` (`site_id`)
		) $charset_collate;";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		foreach ($queries as $query) {
			dbDelta($query);
		}

		if (! self::tables_exist()) {
			return false;
		}

		// Update database version only after every required table exists.
		update_option('cleara11y_db_version', CLEARA11Y_DB_VERSION);
		return true;
	}

	/**
	 * Drop all custom tables.
	 *
	 * @return bool True if successful.
	 */
	public static function drop_tables(): bool {
		global $wpdb;

		$prefix = self::get_prefix();
		$tables = [
			"{$prefix}scans",
			"{$prefix}scan_items",
			"{$prefix}issues",
			"{$prefix}occurrence_states",
			"{$prefix}scan_jobs",
		];

		foreach ($tables as $table) {
			$wpdb->query("DROP TABLE IF EXISTS `$table`"); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Plugin-owned schema operation; read current database state during migrations; Identifiers and DDL fragments come from the fixed plugin schema; values use placeholders.
		}

		delete_option('cleara11y_db_version');

		return true;
	}

	/**
	 * Recreate all tables (for development/debugging).
	 *
	 * @return bool True if successful.
	 */
	public static function recreate_tables(): bool {
		self::drop_tables();
		return self::create_tables();
	}

	/**
	 * Check if tables exist.
	 *
	 * @return bool True if all tables exist.
	 */
	public static function tables_exist(): bool {
		global $wpdb;

		$prefix = self::get_prefix();
		$tables = [
			"{$prefix}scans",
			"{$prefix}scan_items",
			"{$prefix}issues",
			"{$prefix}occurrence_states",
			"{$prefix}scan_jobs",
		];

		foreach ($tables as $table) {
			$result = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $wpdb->esc_like($table))); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Plugin-owned schema operation; read current database state during migrations.
			if ($result !== $table) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Add evidence columns to issues table (for existing installations).
	 *
	 * @return bool True if successful.
	 */
	public static function add_evidence_columns(): bool {
		global $wpdb;

		$table = self::get_table_name('issues');

		// Check if selector_score column exists (if yes, evidence columns already added)
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Plugin-owned schema operation; read current database state during migrations.
		$column_exists = $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS
				WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND COLUMN_NAME = %s',
				$table,
				'selector_score'
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		if ($column_exists) {
			return true; // Already migrated
		}

		// Add new columns
		$columns = [
			"selector_score INT(11) DEFAULT NULL",
			"selector_match_count INT(11) DEFAULT NULL",
			"xpath VARCHAR(500) DEFAULT NULL",
			"dom_path TEXT DEFAULT NULL",
			"ancestor_chain TEXT DEFAULT NULL",
			"accessible_name VARCHAR(500) DEFAULT NULL",
			"inner_text_snippet VARCHAR(500) DEFAULT NULL",
			"bounding_box VARCHAR(100) DEFAULT NULL",
			"computed_style TEXT DEFAULT NULL",
			"fingerprint_strict VARCHAR(64) DEFAULT NULL",
			"fingerprint_loose VARCHAR(64) DEFAULT NULL",
			"signature_version INT(11) DEFAULT 1",
			"node_evidence LONGTEXT DEFAULT NULL",
		];

		foreach ($columns as $column) {
			$result = $wpdb->query("ALTER TABLE `{$table}` ADD COLUMN {$column}"); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Plugin-owned schema operation; read current database state during migrations; Identifiers and DDL fragments come from the fixed plugin schema; values use placeholders.
			if ($result === false) {
				\cleara11y_debug_log("ClearA11y: Failed to add column {$column} to {$table}");
				return false;
			}
		}

		// Add indexes
		$indexes = [
			"ADD INDEX fingerprint_strict (fingerprint_strict)",
			"ADD INDEX fingerprint_loose (fingerprint_loose)",
		];

		foreach ($indexes as $index) {
			// Check if index exists first
			$index_name = preg_match('/INDEX\s+(\w+)/', $index, $matches) ? $matches[1] : '';
			if ($index_name) {
				// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Plugin-owned schema operation; read current database state during migrations; Identifiers and DDL fragments come from the fixed plugin schema; values use placeholders.
				$index_exists = $wpdb->get_var(
					$wpdb->prepare("SHOW INDEX FROM `{$table}` WHERE Key_name = %s", $index_name)
				);
				// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				if (!$index_exists) {
					$wpdb->query("ALTER TABLE `{$table}` {$index}"); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Plugin-owned schema operation; read current database state during migrations; Identifiers and DDL fragments come from the fixed plugin schema; values use placeholders.
				}
			}
		}

		return true;
	}

	/**
	 * Add global dismiss columns to issues table (for existing installations).
	 *
	 * @return bool True if successful.
	 */
	public static function add_global_dismiss_columns(): bool {
		global $wpdb;

		$table = self::get_table_name('issues');

		// Check if dismissed_global column exists
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Plugin-owned schema operation; read current database state during migrations.
		$column_exists = $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS
				WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND COLUMN_NAME = %s',
				$table,
				'dismissed_global'
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		if ($column_exists) {
			return true; // Already migrated
		}

		// Add new columns for global dismissal
		$columns = [
			"dismissed_global TINYINT(1) NOT NULL DEFAULT 0",
			"dismissed_global_by BIGINT(20) UNSIGNED DEFAULT NULL",
			"dismissed_global_at DATETIME DEFAULT NULL",
			"dismissed_global_comment TEXT DEFAULT NULL",
		];

		foreach ($columns as $column) {
			$result = $wpdb->query("ALTER TABLE `{$table}` ADD COLUMN {$column}"); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Plugin-owned schema operation; read current database state during migrations; Identifiers and DDL fragments come from the fixed plugin schema; values use placeholders.
			if ($result === false) {
				\cleara11y_debug_log("ClearA11y: Failed to add column {$column} to {$table}");
				return false;
			}
		}

		// Add index for dismissed_global
		$wpdb->query("ALTER TABLE `{$table}` ADD INDEX dismissed_global (dismissed_global)"); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Plugin-owned schema operation; read current database state during migrations; Identifiers and DDL fragments come from the fixed plugin schema; values use placeholders.

		return true;
	}

	/**
	 * Add scan_jobs table for parallel scanning with job leasing.
	 *
	 * @return bool True if successful.
	 */
	public static function add_scan_jobs_table(): bool {
		global $wpdb;

		$table_name = self::get_table_name('scan_jobs');

		// Check if table already exists
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Plugin-owned schema operation; read current database state during migrations.
		$table_exists = $wpdb->get_var(
			$wpdb->prepare("SHOW TABLES LIKE %s", $wpdb->esc_like($table_name))
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		if ($table_exists === $table_name) {
			return true; // Already exists
		}

		$charset_collate = $wpdb->get_charset_collate();

		$query = "CREATE TABLE `{$table_name}` (
			`id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			`site_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
			`url` text NOT NULL,
			`post_id` bigint(20) UNSIGNED NOT NULL,
			`scan_id` bigint(20) UNSIGNED NOT NULL,
			`status` varchar(20) NOT NULL DEFAULT 'pending',
			`priority` int(11) NOT NULL DEFAULT 0,
			`attempts` int(11) NOT NULL DEFAULT 0,
			`lease_token` varchar(64) DEFAULT NULL,
			`lease_expires_at` datetime DEFAULT NULL,
			`last_error` text DEFAULT NULL,
			`last_started_at` datetime DEFAULT NULL,
			`last_finished_at` datetime DEFAULT NULL,
			`result_json` longtext DEFAULT NULL,
			`created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			`updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY (`id`),
			KEY `status_priority` (`status`, `priority`),
			KEY `lease_expires` (`lease_expires_at`),
			KEY `post_id` (`post_id`),
			KEY `scan_id` (`scan_id`),
			KEY `site_id` (`site_id`)
		) $charset_collate;";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta($query);

		// Verify table was created
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Plugin-owned schema operation; read current database state during migrations.
		$created = $wpdb->get_var(
			$wpdb->prepare("SHOW TABLES LIKE %s", $wpdb->esc_like($table_name))
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return $created === $table_name;
	}

	/**
	 * Add scoring columns to scan_items table (for existing installations).
	 *
	 * @return bool True if successful.
	 */
	public static function add_scoring_columns(): bool {
		global $wpdb;

		$table = self::get_table_name('scan_items');

		// Check if pass_percentage column exists (if yes, scoring columns already added)
		if (self::scan_items_have_scoring_columns()) {
			return true; // Already migrated
		}

		// Add new columns for scoring
		$columns = [
			"rules_checked INT(11) NOT NULL DEFAULT 0",
			"rules_passed INT(11) NOT NULL DEFAULT 0",
			"rules_failed INT(11) NOT NULL DEFAULT 0",
			"rules_incomplete INT(11) NOT NULL DEFAULT 0",
			"pass_percentage DECIMAL(5,2) NOT NULL DEFAULT 0.00",
			"fail_percentage DECIMAL(5,2) NOT NULL DEFAULT 0.00",
			"score_grade VARCHAR(1) DEFAULT NULL",
			"rules_checked_list LONGTEXT DEFAULT NULL",
			"rules_passed_list LONGTEXT DEFAULT NULL",
			"rules_failed_list LONGTEXT DEFAULT NULL",
			"rules_incomplete_list LONGTEXT DEFAULT NULL",
		];

		foreach ($columns as $column) {
			$result = $wpdb->query("ALTER TABLE `{$table}` ADD COLUMN {$column}"); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Plugin-owned schema operation; read current database state during migrations; Identifiers and DDL fragments come from the fixed plugin schema; values use placeholders.
			if ($result === false) {
				\cleara11y_debug_log("ClearA11y: Failed to add column {$column} to {$table}");
				return false;
			}
		}

		// Add indexes for scoring
		$indexes = [
			"ADD INDEX pass_percentage (pass_percentage)",
			"ADD INDEX score_grade (score_grade)",
		];

		foreach ($indexes as $index) {
			// Check if index exists first
			$index_name = preg_match('/INDEX\s+(\w+)/', $index, $matches) ? $matches[1] : '';
			if ($index_name) {
				// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Plugin-owned schema operation; read current database state during migrations; Identifiers and DDL fragments come from the fixed plugin schema; values use placeholders.
				$index_exists = $wpdb->get_var(
					$wpdb->prepare("SHOW INDEX FROM `{$table}` WHERE Key_name = %s", $index_name)
				);
				// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				if (!$index_exists) {
					$wpdb->query("ALTER TABLE `{$table}` {$index}"); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Plugin-owned schema operation; read current database state during migrations; Identifiers and DDL fragments come from the fixed plugin schema; values use placeholders.
				}
			}
		}

		return true;
	}

	/**
	 * Check whether scan_items has the scoring columns used by Scan_Item_Repository.
	 *
	 * @return bool True if scoring columns exist.
	 */
	public static function scan_items_have_scoring_columns(): bool {
		global $wpdb;

		$table = self::get_table_name('scan_items');

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Plugin-owned schema operation; read current database state during migrations.
		$column_exists = $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS
				WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND COLUMN_NAME = %s',
				$table,
				'pass_percentage'
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return !empty($column_exists);
	}

	/**
	 * Recalculate scoring data for existing completed scan items.
	 * This uses stored issue data to estimate scoring (won't be as accurate as a full re-scan).
	 *
	 * @return array {
	 *     @type int $processed Number of scan items processed.
	 *     @type int $updated  Number of scan items updated.
	 *     @type string $message Result message.
	 * }
	 */
	public static function recalculate_scoring_data(): array {
		global $wpdb;

		$scan_items_table = self::get_table_name('scan_items');
		$issues_table = self::get_table_name('issues');

		// Get all completed scan items that don't have scoring data yet
		// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Plugin-owned schema operation; read current database state during migrations; Identifiers and DDL fragments come from the fixed plugin schema; values use placeholders.
		$scan_items = $wpdb->get_results(
			"SELECT * FROM `{$scan_items_table}`
			WHERE status = 'completed'
			AND rules_checked = 0
			ORDER BY id ASC
			LIMIT 500"
		);
		// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		if (empty($scan_items)) {
			return [
				'processed' => 0,
				'updated' => 0,
				'message' => 'No scan items need scoring recalculation.',
			];
		}

		$processed = 0;
		$updated = 0;

		foreach ($scan_items as $item) {
			$processed++;

			// Get all issues for this scan item, grouped by rule_id
			// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Plugin-owned schema operation; read current database state during migrations; Identifiers and DDL fragments come from the fixed plugin schema; values use placeholders.
			$issues = $wpdb->get_results($wpdb->prepare(
				"SELECT rule_id, severity FROM `{$issues_table}`
				WHERE scan_item_id = %d
				GROUP BY rule_id",
				$item->id
			));
			// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

			$failed_rules = [];
			foreach ($issues as $issue) {
				$failed_rules[] = $issue->rule_id;
			}

			// For now, we can only determine failed rules from stored issues
			// We don't have complete data for passed/incomplete/inapplicable rules
			// So we'll calculate based on what we know
			$total_rules = count($failed_rules);
			$passed_rules = 0; // Unknown without re-scan
			$failed_rules_count = $total_rules;
			$incomplete_count = 0; // Unknown without re-scan

			// Calculate pass percentage (assume failed rules are the only ones we know about)
			// This is a conservative estimate - actual score might be better
			$completed_rules = $total_rules - $incomplete_count;
			$pass_percentage = $completed_rules > 0 ? 0 : 100; // All known rules failed
			$fail_percentage = $completed_rules > 0 ? 100 : 0;

			// Get grade
			$grade = self::calculate_grade_from_percentage($pass_percentage);

			// Update scan item
			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Plugin-owned schema operation; read current database state during migrations.
			$update_result = $wpdb->update(
				$scan_items_table,
				[
					'rules_checked' => $total_rules,
					'rules_passed' => $passed_rules,
					'rules_failed' => $failed_rules_count,
					'rules_incomplete' => $incomplete_count,
					'pass_percentage' => $pass_percentage,
					'fail_percentage' => $fail_percentage,
					'score_grade' => $grade,
					'rules_failed_list' => !empty($failed_rules) ? wp_json_encode($failed_rules) : null,
				],
				['id' => $item->id],
				['%d', '%d', '%d', '%d', '%f', '%f', '%s', '%s'],
				['%d']
			);
			// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

			if ($update_result !== false) {
				$updated++;
			}
		}

		return [
			'processed' => $processed,
			'updated' => $updated,
			'message' => sprintf(
				'Processed %d scan items, updated %d with scoring data.',
				$processed,
				$updated
			),
		];
	}

	/**
	 * Add indexes used by the issue explorer projections.
	 *
	 * @return bool True when all indexes exist.
	 */
	public static function add_issue_explorer_indexes(): bool {
		global $wpdb;

		$indexes = [
			self::get_table_name('scan_items') => [
				'latest_completed_post' => '(`post_id`, `status`, `scanned_at`, `id`)',
			],
			self::get_table_name('issues') => [
				'explorer_scan_filters' => '(`scan_id`, `severity`, `rule_id`, `post_id`, `id`)',
				'explorer_live_filters' => '(`scan_item_id`, `severity`, `rule_id`, `id`)',
			],
		];

		foreach ($indexes as $table => $table_indexes) {
			foreach ($table_indexes as $name => $columns) {
				// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Plugin-owned schema operation; read current database state during migrations; Identifiers and DDL fragments come from the fixed plugin schema; values use placeholders.
				$exists = $wpdb->get_var(
					$wpdb->prepare("SHOW INDEX FROM `{$table}` WHERE Key_name = %s", $name)
				);
				// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				if (! $exists && false === $wpdb->query("ALTER TABLE `{$table}` ADD INDEX `{$name}` {$columns}")) { // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Plugin-owned schema operation; read current database state during migrations; Identifiers and DDL fragments come from the fixed plugin schema; values use placeholders.
					return false;
				}
			}
		}

		return true;
	}

	/**
	 * Add explicit axe result classification to observations.
	 *
	 * @return bool True on success.
	 */
	public static function add_result_type_column(): bool {
		global $wpdb;

		$table = self::get_table_name('issues');
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Plugin-owned schema operation; read current database state during migrations.
		$column_exists = $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS
				WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND COLUMN_NAME = %s',
				$table,
				'result_type'
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		if (! $column_exists) {
			// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Plugin-owned schema operation; read current database state during migrations; Identifiers and DDL fragments come from the fixed plugin schema; values use placeholders.
			$result = $wpdb->query(
				"ALTER TABLE `{$table}`
				ADD COLUMN result_type VARCHAR(20) NOT NULL DEFAULT 'violation' AFTER rule_type"
			);
			// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			if (false === $result) {
				\cleara11y_debug_log('ClearA11y: Failed to add result_type to issues table.');
				return false;
			}
		}

		// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Plugin-owned schema operation; read current database state during migrations; Identifiers and DDL fragments come from the fixed plugin schema; values use placeholders.
		$index_exists = $wpdb->get_var(
			"SHOW INDEX FROM `{$table}` WHERE Key_name = 'result_type'"
		);
		// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if (! $index_exists) {
			$result = $wpdb->query("ALTER TABLE `{$table}` ADD INDEX result_type (result_type)"); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Plugin-owned schema operation; read current database state during migrations; Identifiers and DDL fragments come from the fixed plugin schema; values use placeholders.
			if (false === $result) {
				\cleara11y_debug_log('ClearA11y: Failed to index issues.result_type.');
				return false;
			}
		}

		return true;
	}

	/**
	 * Add stable source-attribution fields to occurrence storage.
	 *
	 * @return bool True when all columns and indexes exist.
	 */
	public static function add_source_attribution_columns(): bool {
		global $wpdb;

		$table = self::get_table_name('issues');
		$columns = [
			'source_type' => 'VARCHAR(30) DEFAULT NULL',
			'source_ref' => 'VARCHAR(500) DEFAULT NULL',
			'owner_type' => 'VARCHAR(30) DEFAULT NULL',
			'owner_name' => 'VARCHAR(255) DEFAULT NULL',
			'source_key' => 'VARCHAR(64) DEFAULT NULL',
		];

		foreach ($columns as $column => $definition) {
			if (! self::column_exists($table, $column)) {
				$result = $wpdb->query("ALTER TABLE `{$table}` ADD COLUMN `{$column}` {$definition}"); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Plugin-owned schema operation; read current database state during migrations; Identifiers and DDL fragments come from the fixed plugin schema; values use placeholders.
				if (false === $result) {
					\cleara11y_debug_log(
						sprintf(
							'ClearA11y ERROR: Failed adding source-attribution column. table=%s column=%s database_error=%s',
							$table,
							$column,
							'Database operation failed; raw details omitted to protect scan evidence.'
						)
					);
					return false;
				}
			}
		}

		foreach (['source_key', 'owner_type'] as $index) {
			if (! self::index_exists($table, $index)) {
				$result = $wpdb->query("ALTER TABLE `{$table}` ADD INDEX `{$index}` (`{$index}`)"); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Plugin-owned schema operation; read current database state during migrations; Identifiers and DDL fragments come from the fixed plugin schema; values use placeholders.
				if (false === $result) {
					\cleara11y_debug_log(
						sprintf(
							'ClearA11y ERROR: Failed adding source-attribution index. table=%s index=%s database_error=%s',
							$table,
							$index,
							'Database operation failed; raw details omitted to protect scan evidence.'
						)
					);
					return false;
				}
			}
		}

		return true;
	}

	/**
	 * Add separated v2 element and violation identity fields.
	 *
	 * @return bool True when all columns and indexes exist.
	 */
	public static function add_v2_identity_columns(): bool {
		global $wpdb;

		$table = self::get_table_name('issues');
		$columns = [
			'page_object_key' => 'VARCHAR(500) DEFAULT NULL',
			'element_identity_v2' => 'VARCHAR(64) DEFAULT NULL',
			'element_identity_v2_inputs' => 'LONGTEXT DEFAULT NULL',
			'violation_identity_v2' => 'VARCHAR(64) DEFAULT NULL',
			'violation_identity_v2_inputs' => 'LONGTEXT DEFAULT NULL',
			'identity_signature_version' => 'INT(11) DEFAULT NULL',
		];

		foreach ($columns as $column => $definition) {
			if (! self::column_exists($table, $column)) {
				$result = $wpdb->query("ALTER TABLE `{$table}` ADD COLUMN `{$column}` {$definition}"); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Plugin-owned schema operation; read current database state during migrations; Identifiers and DDL fragments come from the fixed plugin schema; values use placeholders.
				if (false === $result) {
					\cleara11y_debug_log(
						sprintf(
							'ClearA11y ERROR: Failed adding v2 identity column. table=%s column=%s database_error=%s',
							$table,
							$column,
							'Database operation failed; raw details omitted to protect scan evidence.'
						)
					);
					return false;
				}
			}
		}

		$indexes = [
			'page_object_key' => '`page_object_key`(191)',
			'element_identity_v2' => '`element_identity_v2`',
			'violation_identity_v2' => '`violation_identity_v2`',
		];
		foreach ($indexes as $index => $definition) {
			if (! self::index_exists($table, $index)) {
				$result = $wpdb->query("ALTER TABLE `{$table}` ADD INDEX `{$index}` ({$definition})"); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Plugin-owned schema operation; read current database state during migrations; Identifiers and DDL fragments come from the fixed plugin schema; values use placeholders.
				if (false === $result) {
					\cleara11y_debug_log(
						sprintf(
							'ClearA11y ERROR: Failed adding v2 identity index. table=%s index=%s database_error=%s',
							$table,
							$index,
							'Database operation failed; raw details omitted to protect scan evidence.'
						)
					);
					return false;
				}
			}
		}

		return true;
	}

	/**
	 * Add the canonical v2 occurrence state table.
	 *
	 * Existing issue rows remain immutable scan observations; this table is
	 * populated only by new evidence-backed scans.
	 *
	 * @return bool True when the table exists.
	 */
	public static function add_occurrence_state_table(): bool {
		global $wpdb;

		$table = self::get_table_name('occurrence_states');
		$charset_collate = $wpdb->get_charset_collate();
		$query = "CREATE TABLE `{$table}` (
			`id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			`site_id` bigint(20) UNSIGNED NOT NULL,
			`violation_identity_v2` varchar(64) NOT NULL,
			`element_identity_v2` varchar(64) NOT NULL,
			`identity_signature_version` int(11) NOT NULL,
			`page_object_key` varchar(500) NOT NULL,
			`post_id` bigint(20) UNSIGNED NOT NULL,
			`rule_id` varchar(100) NOT NULL,
			`status` varchar(20) NOT NULL DEFAULT 'active',
			`first_seen_at` datetime NOT NULL,
			`last_seen_at` datetime NOT NULL,
			`resolved_at` datetime DEFAULT NULL,
			`reappearance_count` int(11) UNSIGNED NOT NULL DEFAULT 0,
			`latest_issue_id` bigint(20) UNSIGNED NOT NULL,
			`latest_scan_id` bigint(20) UNSIGNED NOT NULL,
			`created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			`updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY (`id`),
			UNIQUE KEY `site_violation_signature` (`site_id`, `violation_identity_v2`, `identity_signature_version`),
			KEY `active_page` (`site_id`, `status`, `page_object_key`(150)),
			KEY `latest_issue_id` (`latest_issue_id`),
			KEY `latest_scan_id` (`latest_scan_id`),
			KEY `element_identity_v2` (`element_identity_v2`)
		) {$charset_collate};";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta($query);

		$created = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table))); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Plugin-owned schema operation; read current database state during migrations.
		if ($created !== $table) {
			\cleara11y_debug_log(
				sprintf(
					'ClearA11y ERROR: Failed creating occurrence state table. table=%s database_error=%s',
					$table,
					'Database operation failed; raw details omitted to protect scan evidence.'
				)
			);
			return false;
		}

		return true;
	}

	/**
	 * Check whether a table column exists.
	 *
	 * @param string $table Table name.
	 * @param string $column Column name.
	 * @return bool
	 */
	private static function column_exists(string $table, string $column): bool {
		global $wpdb;

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Plugin-owned schema operation; read current database state during migrations.
		return (bool) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS
				WHERE TABLE_SCHEMA = DATABASE()
				AND TABLE_NAME = %s
				AND COLUMN_NAME = %s',
				$table,
				$column
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/**
	 * Check whether a table index exists.
	 *
	 * @param string $table Table name.
	 * @param string $index Index name.
	 * @return bool
	 */
	private static function index_exists(string $table, string $index): bool {
		global $wpdb;

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Plugin-owned schema operation; read current database state during migrations.
		return (bool) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT INDEX_NAME FROM INFORMATION_SCHEMA.STATISTICS
				WHERE TABLE_SCHEMA = DATABASE()
				AND TABLE_NAME = %s
				AND INDEX_NAME = %s',
				$table,
				$index
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/**
	 * Calculate letter grade from pass percentage.
	 *
	 * @param float $pass_percentage Pass percentage (0-100).
	 * @return string Letter grade (A-F).
	 */
	private static function calculate_grade_from_percentage(float $pass_percentage): string {
		if ($pass_percentage >= 95) {
			return 'A';
		} elseif ($pass_percentage >= 85) {
			return 'B';
		} elseif ($pass_percentage >= 70) {
			return 'C';
		} elseif ($pass_percentage >= 50) {
			return 'D';
		} else {
			return 'F';
		}
	}

	/**
	 * Add template column to scan_items table (for existing installations).
	 *
	 * @return bool True if successful.
	 */
	public static function add_template_column(): bool {
		global $wpdb;

		$table = self::get_table_name('scan_items');

		if (self::scan_items_have_template_column()) {
			return true;
		}

		$result = $wpdb->query("ALTER TABLE `{$table}` ADD COLUMN `template` VARCHAR(255) DEFAULT NULL"); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Plugin-owned schema operation; read current database state during migrations; Identifiers and DDL fragments come from the fixed plugin schema; values use placeholders.

		if (false === $result) {
			\cleara11y_debug_log(
				sprintf(
					'ClearA11y ERROR: Failed adding template column. table=%s database_error=%s',
					$table,
					'Database operation failed; raw details omitted to protect scan evidence.'
				)
			);
			return false;
		}

		return true;
	}

	/**
	 * Check whether scan items can store the resolved WordPress template.
	 *
	 * @return bool True when the template column exists.
	 */
	public static function scan_items_have_template_column(): bool {
		global $wpdb;

		$table = self::get_table_name('scan_items');
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Plugin-owned schema operation; read current database state during migrations.
		$column = $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COLUMN_NAME
				FROM INFORMATION_SCHEMA.COLUMNS
				WHERE TABLE_SCHEMA = DATABASE()
					AND TABLE_NAME = %s
					AND COLUMN_NAME = %s',
				$table,
				'template'
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return 'template' === $column;
	}
}
