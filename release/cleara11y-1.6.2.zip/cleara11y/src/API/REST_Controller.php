<?php
/**
 * REST API Controller
 *
 * Handles REST API endpoints for scan operations.
 *
 * @package ClearA11y
 * @namespace ClearA11y\API
 */

namespace ClearA11y\API;

if (! defined('ABSPATH')) {
	exit;
}

use ClearA11y\Admin\Scans_Page;
use ClearA11y\Database\Issue_Repository;
use ClearA11y\Database\Job_Repository;
use ClearA11y\Database\Scan_Item_Repository;
use ClearA11y\Database\Scan_Repository;
use ClearA11y\Services\Scan_Results_Processor;
use ClearA11y\Services\Scan_Token_Manager;

/**
 * REST Controller Class
 */
class REST_Controller {

	/**
	 * API namespace.
	 *
	 * @var string
	 */
	private const NAMESPACE = 'cleara11y/v1';

	/**
	 * Maximum request size accepted by scan result endpoints.
	 *
	 * This remains below the plugin's documented minimum PHP post limit so
	 * oversized evidence fails with an actionable response when WordPress can
	 * still receive the request.
	 *
	 * @var int
	 */
	private const MAX_SCAN_RESULT_REQUEST_BYTES = 6291456;

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action('rest_api_init', [$this, 'register_routes']);

	}

	/**
	 * Register REST API routes.
	 */
	public function register_routes(): void {
		register_rest_route(
			self::NAMESPACE,
			'/posts/(?P<id>\d+)/scan-token',
			[
				'methods' => 'POST',
				'callback' => [$this, 'generate_scan_token'],
				'permission_callback' => [$this, 'edit_post_permission'],
				'args' => [
					'id' => [
						'required' => true,
						'type' => 'integer',
						'description' => 'Post ID.',
					],
					'scan_type' => [
						'type' => 'string',
						'default' => 'individual',
						'enum' => ['individual', 'full'],
						'description' => 'Type of scan.',
					],
				],
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/scan/results',
			[
				'methods' => 'POST',
				'callback' => [$this, 'submit_scan_results'],
				'permission_callback' => '__return_true',
				'args' => [
					'token' => [
						'required' => true,
						'type' => 'string',
						'description' => 'Scan token.',
					],
					'results' => [
						'required' => true,
						'type' => 'object',
						'description' => 'Axe-core scan results.',
					],
					'evidence' => [
						'required' => false,
						'type' => 'array',
						'description' => 'Evidence data extracted from violations.',
						'items' => ['type' => 'object'],
					],
				],
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/scans',
			[
				[
					'methods' => 'GET',
					'callback' => [$this, 'get_scans'],
					'permission_callback' => [$this, 'manage_options_permission'],
					'args' => [
						'status' => [
							'type' => 'string',
							'description' => 'Filter by status.',
						],
						'scan_type' => [
							'type' => 'string',
							'description' => 'Filter by scan type.',
						],
						'per_page' => [
							'type' => 'integer',
							'default' => 20,
							'minimum' => 1,
							'maximum' => 100,
						],
						'page' => [
							'type' => 'integer',
							'default' => 1,
							'minimum' => 1,
						],
					],
				],
				[
					'methods' => 'POST',
					'callback' => [$this, 'create_scan'],
					'permission_callback' => [$this, 'manage_options_permission'],
					'args' => [
						'scan_type' => ['type' => 'string', 'enum' => \ClearA11y\Models\Scan::SCAN_TYPES, 'default' => 'full'],
						'scan_name' => ['type' => 'string', 'sanitize_callback' => 'sanitize_text_field'],
					],
				],
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/scans/(?P<id>\d+)',
			[
				'methods' => 'GET',
				'callback' => [$this, 'get_scan'],
				'permission_callback' => [$this, 'manage_options_permission'],
				'args' => [
					'id' => [
						'required' => true,
						'type' => 'integer',
					],
				],
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/scans/(?P<id>\d+)/issues',
			[
				'methods' => 'GET',
				'callback' => [$this, 'get_scan_issues'],
				'permission_callback' => [$this, 'manage_options_permission'],
				'args' => [
					'id' => [
						'required' => true,
						'type' => 'integer',
					],
					'severity' => [
						'type' => 'string',
						'enum' => ['critical', 'moderate', 'minor'],
						'description' => 'Filter by severity.',
					],
				],
			]
		);

		// Get scan stats (job counts for a specific scan)
		register_rest_route(
			self::NAMESPACE,
			'/scans/(?P<id>\d+)/stats',
			[
				'methods' => 'GET',
				'callback' => [$this, 'get_scan_stats'],
				'permission_callback' => [$this, 'manage_options_permission'],
				'args' => [
					'id' => [
						'required' => true,
						'type' => 'integer',
						'description' => 'Scan ID',
					],
				],
			]
		);

		// Get active scan (for global scanner auto-resume)
		register_rest_route(
			self::NAMESPACE,
			'/scan/active',
			[
				'methods' => 'GET',
				'callback' => [$this, 'get_active_scan'],
				'permission_callback' => [$this, 'manage_options_permission'],
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/posts/(?P<id>\d+)/issues',
			[
				'methods' => 'GET',
				'callback' => [$this, 'get_post_issues'],
				'permission_callback' => [$this, 'edit_post_permission'],
				'args' => [
					'id' => [
						'required' => true,
						'type' => 'integer',
					],
				],
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/scan-items/(?P<id>\d+)/issues',
			[
				'methods' => 'GET',
				'callback' => [$this, 'get_scan_item_issues'],
				'permission_callback' => [$this, 'manage_options_permission'],
				'args' => [
					'id' => [
						'required' => true,
						'type' => 'integer',
						'description' => 'Scan Item ID',
					],
				],
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/scan-items/(?P<id>\d+)',
			[
				'methods' => 'GET',
				'callback' => [$this, 'get_scan_item'],
				'permission_callback' => [$this, 'manage_options_permission'],
				'args' => [
					'id' => [
						'required' => true,
						'type' => 'integer',
						'description' => 'Scan Item ID',
					],
				],
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/scan-items/(?P<id>\d+)/fail',
			[
				'methods' => 'POST',
				'callback' => [$this, 'fail_scan_item'],
				'permission_callback' => [$this, 'manage_options_permission'],
				'args' => [
					'id' => [
						'required' => true,
						'type' => 'integer',
						'description' => 'Scan Item ID',
					],
					'error_message' => [
						'type' => 'string',
						'sanitize_callback' => 'sanitize_textarea_field',
						'description' => 'Error message',
					],
				],
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/stats/overview',
			[
				'methods' => 'GET',
				'callback' => [$this, 'get_stats_overview'],
				'permission_callback' => [$this, 'manage_options_permission'],
			]
		);

		// Recent scans route
		register_rest_route(
			self::NAMESPACE,
			'/scans/recent',
			[
				'methods' => 'GET',
				'callback' => [$this, 'get_recent_scans'],
				'permission_callback' => [$this, 'manage_options_permission'],
				'args' => [
					'limit' => [
						'type' => 'integer',
						'default' => 10,
						'minimum' => 1,
						'maximum' => 100,
						'description' => 'Number of recent scans to return.',
					],
				],
			]
		);

		// Queue routes
		register_rest_route(
			self::NAMESPACE,
			'/queue/add',
			[
				'methods' => 'POST',
				'callback' => [$this, 'add_to_queue'],
				'permission_callback' => [$this, 'manage_options_permission'],
				'args' => [
					'post_ids' => [
						'required' => true,
						'type' => 'array',
						'description' => 'Array of post IDs to scan.',
						'items' => ['type' => 'integer'],
					],
					'scan_name' => [
						'type' => 'string',
						'sanitize_callback' => 'sanitize_text_field',
						'description' => 'Name for this scan batch.',
					],
					'scan_type' => [
						'type' => 'string',
						'enum' => ['individual', 'full'],
						'default' => 'full',
						'description' => 'Type of scan being queued.',
					],
				],
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/queue/create-jobs',
			[
				'methods' => 'POST',
				'callback' => [$this, 'create_queue_jobs'],
				'permission_callback' => [$this, 'manage_options_permission'],
				'args' => [
					'post_ids' => [
						'required' => true,
						'type' => 'array',
						'description' => 'Array of post IDs to create jobs for.',
						'items' => ['type' => 'integer'],
					],
					'scan_id' => [
						'required' => true,
						'type' => 'integer',
						'description' => 'Scan ID to associate jobs with.',
					],
					'priority' => [
						'type' => 'integer',
						'default' => 10,
						'description' => 'Job priority (higher = earlier).',
					],
				],
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/queue/status',
			[
				'methods' => 'GET',
				'callback' => [$this, 'get_queue_status'],
				'permission_callback' => [$this, 'manage_options_permission'],
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/queue/next',
			[
				'methods' => 'POST',
				'callback' => [$this, 'get_next_queue_item'],
				'permission_callback' => [$this, 'manage_options_permission'],
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/queue/(?P<scan_id>\d+)/cancel',
			[
				'methods' => 'POST',
				'callback' => [$this, 'cancel_queue_scan'],
				'permission_callback' => [$this, 'manage_options_permission'],
				'args' => [
					'scan_id' => [
						'required' => true,
						'type' => 'integer',
					],
				],
			]
		);

		// Issues routes
		register_rest_route(
			self::NAMESPACE,
			'/issues/occurrences',
			[
				'methods' => 'GET',
				'callback' => [$this, 'get_issue_occurrences'],
				'permission_callback' => [$this, 'manage_options_permission'],
				'args' => [
					'status' => [
						'type' => 'string',
						'enum' => ['active', 'exception', 'all'],
						'default' => 'active',
					],
					'severity' => [
						'type' => 'string',
						'enum' => ['critical', 'moderate', 'minor'],
					],
					'finding_type' => [
						'type' => 'string',
						'enum' => ['violation', 'review'],
					],
					'rule_id' => ['type' => 'string'],
					'page_id' => ['type' => 'integer', 'minimum' => 1],
					'scan_id' => ['type' => 'integer', 'minimum' => 1],
					'search' => ['type' => 'string'],
					'group_by' => [
						'type' => 'string',
						'enum' => ['page', 'rule'],
						'default' => 'page',
					],
					'sort' => [
						'type' => 'string',
						'enum' => ['severity', 'newest', 'page', 'rule'],
						'default' => 'severity',
					],
					'page' => ['type' => 'integer', 'minimum' => 1, 'default' => 1],
					'per_page' => ['type' => 'integer', 'minimum' => 1, 'maximum' => 100, 'default' => 20],
				],
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/issues/occurrences/(?P<id>\d+)',
			[
				'methods' => 'GET',
				'callback' => [$this, 'get_issue_occurrence'],
				'permission_callback' => [$this, 'manage_options_permission'],
				'args' => [
					'id' => ['required' => true, 'type' => 'integer', 'minimum' => 1],
				],
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/issues/filter-options',
			[
				'methods' => 'GET',
				'callback' => [$this, 'get_issue_filter_options'],
				'permission_callback' => [$this, 'manage_options_permission'],
				'args' => [
					'type' => [
						'required' => true,
						'type' => 'string',
						'enum' => ['rule', 'page', 'scan'],
					],
					'search' => ['type' => 'string'],
				],
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/issues/list',
			[
				'methods' => 'GET',
				'callback' => [$this, 'get_issues_list'],
				'permission_callback' => [$this, 'manage_options_permission'],
				'args' => [
					'severity' => [
						'type' => 'string',
						'enum' => ['critical', 'moderate', 'minor'],
						'description' => 'Filter by severity.',
					],
					'status' => [
						'type' => 'string',
						'enum' => ['active', 'exception', 'all'],
						'default' => 'active',
						'description' => 'Filter by exception status.',
					],
					'search' => [
						'type' => 'string',
						'description' => 'Search term for rule_id, post_title, or post_url.',
					],
					'page' => [
						'type' => 'integer',
						'default' => 1,
						'minimum' => 1,
					],
					'per_page' => [
						'type' => 'integer',
						'default' => 20,
						'minimum' => 1,
						'maximum' => 100,
					],
				],
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/issues/stats',
			[
				'methods' => 'GET',
				'callback' => [$this, 'get_issues_stats'],
				'permission_callback' => [$this, 'manage_options_permission'],
			]
		);

		// Issue Types routes
		register_rest_route(
			self::NAMESPACE,
			'/issue-types',
			[
				'methods' => 'GET',
				'callback' => [$this, 'get_issue_types'],
				'permission_callback' => [$this, 'manage_options_permission'],
				'args' => [
					'severity' => [
						'type' => 'string',
						'enum' => ['critical', 'moderate', 'minor'],
						'description' => 'Filter by severity.',
					],
					'search' => [
						'type' => 'string',
						'description' => 'Search term for rule_id or message.',
					],
				],
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/issue-types/(?P<rule_id>[a-zA-Z0-9_-]+)/pages',
			[
				'methods' => 'GET',
				'callback' => [$this, 'get_issue_type_pages'],
				'permission_callback' => [$this, 'manage_options_permission'],
				'args' => [
					'rule_id' => [
						'required' => true,
						'type' => 'string',
						'description' => 'The rule ID to get pages for.',
					],
					'page' => [
						'type' => 'integer',
						'default' => 1,
						'minimum' => 1,
					],
					'per_page' => [
						'type' => 'integer',
						'default' => 20,
						'minimum' => 1,
						'maximum' => 100,
					],
				],
			]
		);

		// Job routes for parallel scanning with leasing
		register_rest_route(
			self::NAMESPACE,
			'/jobs/lease',
			[
				'methods' => 'POST',
				'callback' => [$this, 'lease_jobs'],
				'permission_callback' => [$this, 'manage_options_permission'],
				'args' => [
					'workerId' => [
						'type' => 'string',
						'sanitize_callback' => 'sanitize_text_field',
						'description' => 'Unique identifier for the worker instance.',
					],
					'limit' => [
						'type' => 'integer',
						'default' => 2,
						'minimum' => 1,
						'maximum' => 10,
						'description' => 'Maximum number of jobs to lease.',
					],
					'leaseSeconds' => [
						'type' => 'integer',
						'default' => 180,
						'minimum' => 15,
						'maximum' => 600,
						'description' => 'Lease duration in seconds.',
					],
				],
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/jobs/heartbeat',
			[
				'methods' => 'POST',
				'callback' => [$this, 'job_heartbeat'],
				'permission_callback' => [$this, 'manage_options_permission'],
				'args' => [
					'jobId' => [
						'required' => true,
						'type' => 'integer',
						'description' => 'Job ID to renew lease for.',
					],
					'leaseToken' => [
						'required' => true,
						'type' => 'string',
						'description' => 'Lease token for authentication.',
					],
					'leaseSeconds' => [
						'type' => 'integer',
						'default' => 180,
						'minimum' => 15,
						'maximum' => 600,
						'description' => 'Lease extension duration in seconds.',
					],
				],
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/jobs/complete',
			[
				'methods' => 'POST',
				'callback' => [$this, 'complete_job'],
				'permission_callback' => [$this, 'manage_options_permission'],
				'args' => [
					'jobId' => [
						'required' => true,
						'type' => 'integer',
						'description' => 'Job ID to complete.',
					],
					'leaseToken' => [
						'required' => true,
						'type' => 'string',
						'description' => 'Lease token for authentication.',
					],
					'status' => [
						'required' => true,
						'type' => 'string',
						'enum' => ['done', 'failed'],
						'description' => 'Job completion status.',
					],
					'resultJson' => [
						'type' => 'string',
						'description' => 'JSON-encoded scan results (for done status).',
					],
					'error' => [
						'type' => 'string',
						'sanitize_callback' => 'sanitize_textarea_field',
						'description' => 'Error message (for failed status).',
					],
				],
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/jobs/stats',
			[
				'methods' => 'GET',
				'callback' => [$this, 'get_job_stats'],
				'permission_callback' => [$this, 'manage_options_permission'],
				'args' => [
					'scan_id' => [
						'type' => 'integer',
						'description' => 'Filter stats by scan ID.',
						'required' => false,
					],
				],
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/jobs/expire',
			[
				'methods' => 'POST',
				'callback' => [$this, 'expire_jobs'],
				'permission_callback' => [$this, 'manage_options_permission'],
				'args' => [
					'force' => [
						'type' => 'boolean',
						'default' => false,
						'description' => 'If true, expire ALL active jobs regardless of lease time.',
					],
				],
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/jobs/cleanup',
			[
				'methods' => 'POST',
				'callback' => [$this, 'cleanup_jobs'],
				'permission_callback' => [$this, 'manage_options_permission'],
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/stats/overview',
			[
				'methods' => 'GET',
				'callback' => [$this, 'get_overview_stats'],
				'permission_callback' => [$this, 'manage_options_permission'],
			]
		);

			// Pages routes
			register_rest_route(
				self::NAMESPACE,
				'/pages/list',
				[
					'methods' => 'GET',
					'callback' => [$this, 'get_pages_list'],
					'permission_callback' => [$this, 'manage_options_permission'],
					'args' => [
						'post_type' => [
							'type' => 'string',
							'default' => 'page',
							'description' => 'Filter by post type.',
						],
						'status' => [
							'type' => 'string',
							'enum' => ['scanned', 'unscanned', 'all'],
							'default' => 'all',
							'description' => 'Filter by scan status.',
						],
						'severity' => [
							'type' => 'string',
							'enum' => ['critical', 'moderate', 'minor'],
							'description' => 'Filter by minimum severity.',
						],
						'search' => [
							'type' => 'string',
							'description' => 'Search term for post title or URL.',
						],
						'orderby' => [
							'type' => 'string',
							'enum' => ['title', 'issues', 'score', 'scanned_date'],
							'default' => 'scanned_date',
							'description' => 'Sort order.',
						],
						'order' => [
							'type' => 'string',
							'enum' => ['asc', 'desc'],
							'default' => 'desc',
							'description' => 'Sort direction.',
						],
						'page' => [
							'type' => 'integer',
							'default' => 1,
							'minimum' => 1,
						],
						'per_page' => [
							'type' => 'integer',
							'default' => 20,
							'minimum' => 1,
							'maximum' => 100,
						],
					],
				]
			);
	}

	/**
	 * Generate scan token for a post.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response
	 */
	public function generate_scan_token(\WP_REST_Request $request) {
		// Check if tables exist, if not try to create them
		if (!\ClearA11y\Database\Schema::tables_exist()) {
			\ClearA11y\Database\Schema::create_tables();
		}

		$post_id = (int) $request->get_param('id');
		$scan_type = $request->get_param('scan_type') ?? 'individual';

		// Validate post exists
		$post = get_post($post_id);
		if (!$post || $post->post_status !== 'publish') {
			return new \WP_Error('invalid_post', 'Post not found or not published.', ['status' => 404]);
		}

		try {
			$result = Scan_Token_Manager::generate_token($post_id, $scan_type);

			if (isset($result['error'])) {
				return new \WP_Error('scan_error', $result['error'], ['status' => 400]);
			}

			return rest_ensure_response($result);
		} catch (\Exception $e) {
			return new \WP_Error('scan_exception', $e->getMessage(), ['status' => 500]);
		}
	}

	/**
	 * Submit scan results from client-side scanner.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function submit_scan_results(\WP_REST_Request $request): \WP_REST_Response|\WP_Error {
		$token = $request->get_param('token');
		$results = $request->get_param('results');
		$evidence = $request->get_param('evidence');
		$request_bytes = strlen($request->get_body());

		if ($request_bytes > self::MAX_SCAN_RESULT_REQUEST_BYTES) {
			\cleara11y_debug_log(
				sprintf(
					'ClearA11y ERROR: Rejected oversized scan result request. body_bytes=%d limit_bytes=%d',
					$request_bytes,
					self::MAX_SCAN_RESULT_REQUEST_BYTES
				)
			);
			return rest_ensure_response(
				new \WP_Error(
					'scan_results_too_large',
					'The scan evidence payload is too large to store safely. Reduce the scan scope or increase the server request limits.',
					['status' => 413]
				)
			);
		}

		if (defined('WP_DEBUG') && WP_DEBUG) {
			\cleara11y_debug_log(
				sprintf(
					'ClearA11y REST: scan results received body_bytes=%d evidence_records=%d result_keys=%s',
					strlen($request->get_body()),
					is_array($evidence) ? count($evidence) : 0,
					is_array($results) ? implode(',', array_map('sanitize_key', array_keys($results))) : 'invalid'
				)
			);
		}

		// Validate token
		$token_data = Scan_Token_Manager::validate_token($token);

		if (!$token_data) {
			return rest_ensure_response(
				new \WP_Error('invalid_token', 'Invalid or expired scan token.', ['status' => 403])
			);
		}

		if (! is_array($results) || ! is_array($evidence)) {
			\cleara11y_debug_log('ClearA11y ERROR: Rejected malformed scan result payload.');
			return rest_ensure_response(
				new \WP_Error(
					'invalid_scan_results',
					'The scan results or evidence payload is malformed. Run the scan again.',
					['status' => 400]
				)
			);
		}

		$results['evidence'] = $evidence;
		$results = \ClearA11y\Services\Scan_Result_Sanitizer::sanitize(wp_json_encode($results));
		if (is_wp_error($results)) {
			return $results;
		}
		$evidence = $results['evidence'];

		$finding_nodes = self::count_finding_nodes($results);
		if (count($evidence) < $finding_nodes) {
			\cleara11y_debug_log(
				sprintf(
					'ClearA11y ERROR: Rejected incomplete scan evidence. finding_nodes=%d evidence_records=%d',
					$finding_nodes,
					count($evidence)
				)
			);
			return rest_ensure_response(
				new \WP_Error(
					'incomplete_scan_evidence',
					'The browser did not return evidence for every accessibility finding. Run the scan again and check the browser console if this continues.',
					['status' => 422]
				)
			);
		}

		// Process results with evidence
		$result = Scan_Results_Processor::process_results(
			$token_data['scan_item_id'],
			$results,
			$evidence
		);

		if (! empty($result['success'])) {
			Scan_Token_Manager::delete_token($token);
		}

		return rest_ensure_response($result);
	}

	/**
	 * Get scans list.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response
	 */
	public function get_scans(\WP_REST_Request $request): \WP_REST_Response {
		$status = $request->get_param('status');
		$scan_type = $request->get_param('scan_type');
		$per_page = $request->get_param('per_page') ?? 20;
		$page = $request->get_param('page') ?? 1;
		$offset = ($page - 1) * $per_page;

		$args = [
			'status' => $status,
			'scan_type' => $scan_type,
			'limit' => $per_page,
			'offset' => $offset,
		];

		$scans = Scan_Repository::get_all($args);
		$total = Scan_Repository::get_count($status ?? null);

		return rest_ensure_response([
			'data' => $scans,
			'total' => $total,
			'pages' => ceil($total / $per_page),
			'current_page' => $page,
		]);
	}

	/**
	 * Create a new scan.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response
	 */
	public function create_scan(\WP_REST_Request $request): \WP_REST_Response|\WP_Error {
		// Check if there's already an active scan
		if (\ClearA11y\Services\Scan_Orchestrator::has_active_scan()) {
			return rest_ensure_response(
				new \WP_Error('scan_already_active',
					'Another scan is already in progress. Please wait for it to complete before starting a new scan.',
					['status' => 409]
				)
			);
		}

		$scan_type = $request->get_param('scan_type') ?? 'full';
		$scan_name = $request->get_param('scan_name');
		if (! in_array($scan_type, \ClearA11y\Models\Scan::SCAN_TYPES, true) || (null !== $scan_name && ! is_string($scan_name))) {
			return new \WP_Error('invalid_scan', 'Invalid scan type or name.', ['status' => 400]);
		}

		$scan = new \ClearA11y\Models\Scan();
		$scan->scan_type = $scan_type;
		$scan->scan_name = null === $scan_name ? null : sanitize_text_field($scan_name);
		$scan->status = 'pending';
		$scan->total_items = 0;
		$scan->created_at = current_time('mysql', true);

		$scan_id = Scan_Repository::insert($scan);

		if (!$scan_id) {
			return rest_ensure_response(
				new \WP_Error('scan_error', 'Failed to create scan.', ['status' => 500])
			);
		}

		return rest_ensure_response([
			'id' => $scan_id,
			'message' => 'Scan created successfully.',
		]);
	}

	/**
	 * Get single scan details.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response
	 */
	public function get_scan(\WP_REST_Request $request): \WP_REST_Response|\WP_Error {
		$scan_id = (int) $request->get_param('id');
		$scan = Scan_Repository::get_by_id($scan_id);

		if (!$scan) {
			return rest_ensure_response(
				new \WP_Error('scan_not_found', 'Scan not found.', ['status' => 404])
			);
		}

		// Get scan items
		$scan_items = Scan_Item_Repository::get_by_scan_id($scan_id);

		return rest_ensure_response([
			'scan' => $scan,
			'items' => $scan_items,
		]);
	}

	/**
	 * Get issues for a scan.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response
	 */
	public function get_scan_issues(\WP_REST_Request $request): \WP_REST_Response {
		$scan_id = (int) $request->get_param('id');
		$severity = $request->get_param('severity');

		$args = [
			'severity' => $severity,
		];

		$issues = Issue_Repository::get_by_scan_id($scan_id, $args);

		return rest_ensure_response([
			'data' => $issues,
			'total' => count($issues),
		]);
	}

	/**
	 * Get issues for a post.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response
	 */
	public function get_post_issues(\WP_REST_Request $request): \WP_REST_Response {
		$post_id = (int) $request->get_param('id');
		$issues = Issue_Repository::get_by_post_id($post_id);
		$counts = Issue_Repository::get_post_issue_counts($post_id);

		return rest_ensure_response([
			'counts' => $counts,
			'issues' => $issues,
		]);
	}

	/**
	 * Get issues for a specific scan item.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response
	 */
	public function get_scan_item_issues(\WP_REST_Request $request): \WP_REST_Response|\WP_Error {
		$scan_item_id = (int) $request->get_param('id');

		// Get scan item
		$scan_item = Scan_Item_Repository::get_by_id($scan_item_id);

		if (!$scan_item) {
			return rest_ensure_response(
				new \WP_Error('scan_item_not_found', 'Scan item not found.', ['status' => 404])
			);
		}

		// Get issues for this scan item
		$issues = Issue_Repository::get_by_scan_item_id($scan_item_id);

		return rest_ensure_response([
			'scan_item' => $scan_item,
			'issues' => $issues,
		]);
	}

	/**
	 * Get a single scan item.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response
	 */
	public function get_scan_item(\WP_REST_Request $request): \WP_REST_Response|\WP_Error {
		$scan_item_id = (int) $request->get_param('id');

		// Get scan item
		$scan_item = Scan_Item_Repository::get_by_id($scan_item_id);

		if (!$scan_item) {
			return rest_ensure_response(
				new \WP_Error('scan_item_not_found', 'Scan item not found.', ['status' => 404])
			);
		}

		return rest_ensure_response([
			'scan_item' => $scan_item,
		]);
	}

	/**
	 * Mark a scan item as failed.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response
	 */
	public function fail_scan_item(\WP_REST_Request $request): \WP_REST_Response|\WP_Error {
		$scan_item_id = (int) $request->get_param('id');
		$error_message = sanitize_textarea_field($request->get_param('error_message') ?? 'Scan timed out or failed to complete');

		// Get scan item
		$scan_item = Scan_Item_Repository::get_by_id($scan_item_id);

		if (!$scan_item) {
			return rest_ensure_response(
				new \WP_Error('scan_item_not_found', 'Scan item not found.', ['status' => 404])
			);
		}

		// Only fail if it's currently in_progress
		if ($scan_item->status !== 'in_progress') {
			return rest_ensure_response([
				'success' => false,
				'message' => 'Scan item is not in progress.',
				'current_status' => $scan_item->status,
			]);
		}

		// Update status to failed
		$scan_item->status = 'failed';
		$scan_item->error_message = $error_message;
		Scan_Item_Repository::update($scan_item);

		// Check if parent scan should also be marked as failed
		$scan = Scan_Repository::get_by_id($scan_item->scan_id);
		if ($scan && $scan->status === 'in_progress') {
			// Check if there are any other pending or in_progress items
			$items = Scan_Item_Repository::get_by_scan_id($scan_item->scan_id);
			$active_items = array_filter($items, fn($i) => in_array($i->status, ['pending', 'in_progress'], true));

			if (empty($active_items)) {
				// All items are done - mark scan as failed
				$scan->status = 'failed';
				Scan_Repository::update($scan);
			}
		}

		return rest_ensure_response([
			'success' => true,
			'message' => 'Scan item marked as failed.',
		]);
	}

	/**
	 * Get overview statistics.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response
	 */
	public function get_stats_overview(\WP_REST_Request $request): \WP_REST_Response {
		global $wpdb;

		$latest_scan = Scan_Repository::get_latest_active_or_completed();
		$issues_table = \ClearA11y\Database\Schema::get_table_name('issues');
		$scan_items_table = \ClearA11y\Database\Schema::get_table_name('scan_items');

		// Get scan counts (status only)
		$stats = [
			'total_scans' => Scan_Repository::get_count(),
			'completed_scans' => Scan_Repository::get_count('completed'),
			'pending_scans' => Scan_Repository::get_count('pending'),
			'in_progress_scans' => Scan_Repository::get_count('in_progress'),
		];

		if ($latest_scan) {
			// Calculate actual issue counts from the issues table.
			// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state; Schema-owned identifiers and fixed SQL fragments; variable values are prepared separately.
			$issue_counts = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT severity, COUNT(*) as count
					 FROM `{$issues_table}`
					 WHERE scan_id = %d
					 GROUP BY severity",
					$latest_scan->id
				),
				ARRAY_A
			);
			// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

			$counts = [
				'total' => 0,
				'critical' => 0,
				'moderate' => 0,
				'minor' => 0,
			];

			foreach ($issue_counts as $row) {
				$counts[$row['severity']] = (int) $row['count'];
				$counts['total'] += (int) $row['count'];
			}

			// Get the count of unique pages scanned in the current dashboard scan.
			// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state; Schema-owned identifiers and fixed SQL fragments; variable values are prepared separately.
			$scanned_pages = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(DISTINCT post_id)
					 FROM `{$scan_items_table}`
					 WHERE scan_id = %d AND status = 'completed'",
					$latest_scan->id
				)
			);
			// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

			$stats['latest_scan'] = [
				'id' => $latest_scan->id,
				'scan_type' => $latest_scan->scan_type,
				'scanned_pages' => (int) $scanned_pages,
				'total_issues' => $counts['total'],
				'critical_issues' => $counts['critical'],
				'moderate_issues' => $counts['moderate'],
				'minor_issues' => $counts['minor'],
				'completed_at' => $latest_scan->completed_at,
			];
		}

		return rest_ensure_response($stats);
	}

	/**
	 * Permission callback: Can edit post.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return bool
	 */
	public function edit_post_permission(\WP_REST_Request $request): bool {
		$post_id = (int) $request->get_param('id');
		return current_user_can('edit_post', $post_id);
	}

	/**
	 * Permission callback: Can manage options.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return bool
	 */
	public function manage_options_permission(\WP_REST_Request $request): bool {
		return current_user_can('manage_options');
	}

	/**
	 * Add posts to scan queue.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response
	 */
	public function add_to_queue(\WP_REST_Request $request): \WP_REST_Response|\WP_Error {
		$post_ids = $request->get_param('post_ids');
		$scan_name = $request->get_param('scan_name');
		$scan_name = is_string($scan_name) ? sanitize_text_field($scan_name) : null;
		$scan_type = $request->get_param('scan_type') ?? 'full';

		if (empty($post_ids) || !is_array($post_ids)) {
			return rest_ensure_response(
				new \WP_Error('invalid_posts', 'Invalid post IDs.', ['status' => 400])
			);
		}

		// Check if tables exist
		if (!\ClearA11y\Database\Schema::tables_exist()) {
			\ClearA11y\Database\Schema::create_tables();
		}

		// Create a new scan
		$scan = new \ClearA11y\Models\Scan();
		$scan->scan_type = $scan_type;
		$scan->scan_name = $scan_name ?? 'Batch Scan - ' . count($post_ids) . ' pages';
		$scan->status = 'pending';
		$scan->total_items = count($post_ids);
		$scan->scanned_items = 0;
		$scan->created_at = current_time('mysql', true);

		$scan_id = Scan_Repository::insert($scan);

		if (!$scan_id) {
			return rest_ensure_response(
				new \WP_Error('scan_error', 'Failed to create scan.', ['status' => 500])
			);
		}

		// Create scan items for all posts
		foreach ($post_ids as $post_id) {
			$post = get_post($post_id);

			if (!$post || $post->post_status !== 'publish') {
				continue;
			}

			$scan_item = new \ClearA11y\Models\Scan_Item();
			$scan_item->scan_id = $scan_id;
			$scan_item->post_id = $post_id;
			$scan_item->post_type = $post->post_type;
			$scan_item->post_title = $post->post_title;
			$scan_item->post_url = get_permalink($post_id);
			$scan_item->status = 'pending';
			$scan_item->scan_method = 'client';
			$scan_item->created_at = current_time('mysql', true);

			Scan_Item_Repository::insert($scan_item);
		}

		return rest_ensure_response([
			'scan_id' => $scan_id,
			'total_items' => count($post_ids),
			'message' => 'Scan queue created successfully.',
		]);
	}

	/**
	 * Create jobs in scan_jobs table for parallel processing.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response
	 */
	public function create_queue_jobs(\WP_REST_Request $request): \WP_REST_Response|\WP_Error {
		global $wpdb;

		$post_ids = $request->get_param('post_ids');
		$scan_id = (int) $request->get_param('scan_id');
		$priority = (int) $request->get_param('priority') ?? 10;

		\cleara11y_debug_log(sprintf('[ClearA11y] create_queue_jobs called: scan_id=%d, posts=%d',
			$scan_id, count($post_ids ?? [])));

		if (empty($post_ids) || !is_array($post_ids)) {
			return rest_ensure_response(
				new \WP_Error('invalid_posts', 'Invalid post IDs.', ['status' => 400])
			);
		}

		// Verify scan exists
		$scan = Scan_Repository::get_by_id($scan_id);
		if (!$scan) {
			\cleara11y_debug_log('[ClearA11y] create_queue_jobs: Scan not found: ' . $scan_id);
			return rest_ensure_response(
				new \WP_Error('invalid_scan', 'Scan not found.', ['status' => 404])
			);
		}

		\cleara11y_debug_log(sprintf('[Cleara11y] create_queue_jobs: Scan found: %d (status=%s)',
			$scan->id, $scan->status));

		$jobs_table = \ClearA11y\Database\Schema::get_table_name('scan_jobs');
		$scans_table = \ClearA11y\Database\Schema::get_table_name('scans');
		$created = 0;

		foreach ($post_ids as $post_id) {
			$post = get_post($post_id);

			if (!$post || $post->post_status !== 'publish') {
				continue;
			}

			$url = get_permalink($post_id);

			// Check if job already exists for this post/scan
			// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state; Schema-owned identifiers and fixed SQL fragments; variable values are prepared separately.
			$existing = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT id FROM `{$jobs_table}` WHERE post_id = %d AND scan_id = %d",
					$post_id,
					$scan_id
				)
			);
			// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

			if ($existing) {
				continue; // Skip existing jobs
			}

			// Insert new job
			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery -- Write to plugin-owned tables; no WordPress data API or cached result applies.
			$result = $wpdb->insert(
				$jobs_table,
				[
					'site_id' => get_current_blog_id(),
					'url' => $url,
					'post_id' => $post_id,
					'scan_id' => $scan_id,
					'status' => 'pending',
					'priority' => $priority,
					'created_at' => current_time('mysql', true),
				],
				['%d', '%s', '%d', '%d', '%s', '%d', '%s']
			);
			// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery

			if ($result) {
				$created++;
			}
		}

		\cleara11y_debug_log(sprintf('[ClearA11y] create_queue_jobs: Created %d new jobs', $created));

		// Update scan status to 'in_progress' and set started_at
		if ($created > 0) {
			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Write to plugin-owned tables; no WordPress data API or cached result applies.
			$updated = $wpdb->update(
				$scans_table,
				[
					'status' => 'in_progress',
					'started_at' => current_time('mysql', true),
				],
				['id' => $scan_id],
				['%s', '%s'],
				['%d']
			);
			// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

			\cleara11y_debug_log(sprintf('[ClearA11y] create_queue_jobs: Updated scan %d status to in_progress (result=%d)',
				$scan_id, $updated));
		}

		return rest_ensure_response([
			'scan_id' => $scan_id,
			'jobs_created' => $created,
			'scan_status' => 'in_progress',
			'message' => sprintf('%d jobs created successfully.', $created),
		]);
	}

	/**
	 * Get scan queue status.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response
	 */
	public function get_queue_status(\WP_REST_Request $request): \WP_REST_Response {
		// Get active scans (pending or in_progress)
		$active_scans = Scan_Repository::get_all([
			'status' => null,
			'limit' => 10,
			'orderby' => 'created_at',
			'order' => 'DESC',
		]);

		$queue = [];
		foreach ($active_scans as $scan) {
			if (in_array($scan->status, ['pending', 'in_progress'], true)) {
				$items = Scan_Item_Repository::get_by_scan_id($scan->id);
				$pending = count(array_filter($items, fn($i) => $i->status === 'pending'));
				$completed = count(array_filter($items, fn($i) => $i->status === 'completed'));
				$failed = count(array_filter($items, fn($i) => $i->status === 'failed'));

				$queue[] = [
					'scan_id' => $scan->id,
					'scan_name' => $scan->scan_name,
					'status' => $scan->status,
					'total_items' => $scan->total_items,
					'scanned_items' => $scan->scanned_items,
					'pending' => $pending,
					'completed' => $completed,
					'failed' => $failed,
					'created_at' => $scan->created_at,
				];
			}
		}

		return rest_ensure_response([
			'queue' => $queue,
			'active_count' => count($queue),
		]);
	}

	/**
	 * Get next pending item from queue for background scanning.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response
	 */
	public function get_next_queue_item(\WP_REST_Request $request): \WP_REST_Response {
		global $wpdb;
		$table = \ClearA11y\Database\Schema::get_table_name('scan_items');

		// First, auto-reset any items stuck in "in_progress" for more than 5 minutes
		$stuck_timeout = 5; // minutes
		// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Write to plugin-owned tables; no WordPress data API or cached result applies; Schema-owned identifiers and fixed SQL fragments; variable values are prepared separately.
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE `{$table}` SET status = 'pending', error_message = 'Auto-reset due to timeout'
				WHERE status = 'in_progress'
				AND created_at < DATE_SUB(NOW(), INTERVAL %d MINUTE)",
				$stuck_timeout
			)
		);
		// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		// Find first pending scan item
		// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state; Schema-owned identifiers and fixed SQL fragments; variable values are prepared separately.
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM `{$table}` WHERE status = 'pending' ORDER BY created_at ASC LIMIT 1",
			)
		);
		// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		if (!$row) {
			return rest_ensure_response([
				'item' => null,
				'message' => 'No pending items in queue.',
			]);
		}

		// Mark as in_progress
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Write to plugin-owned tables; no WordPress data API or cached result applies.
		$wpdb->update(
			$table,
			['status' => 'in_progress'],
			['id' => $row->id],
			['%s'],
			['%d']
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		// Validate post exists and is published
		$post = \get_post($row->post_id);
		if (!$post || $post->post_status !== 'publish') {
			// Post doesn't exist or isn't published - mark as failed
			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Write to plugin-owned tables; no WordPress data API or cached result applies.
			$wpdb->update(
				$table,
				[
					'status' => 'failed',
					'error_message' => $post ? 'Post is not published' : 'Post no longer exists'
				],
				['id' => $row->id],
				['%s', '%s'],
				['%d']
			);
			// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

			// Update scan status if this was the last item
			$scan_items_table = \ClearA11y\Database\Schema::get_table_name('scan_items');
			// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state; Schema-owned identifiers and fixed SQL fragments; variable values are prepared separately.
			$pending_count = $wpdb->get_var($wpdb->prepare(
				"SELECT COUNT(*) FROM `{$scan_items_table}` WHERE scan_id = %d AND status = 'pending'",
				$row->scan_id
			));
			// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

			if ($pending_count == 0) {
				$scans_table = \ClearA11y\Database\Schema::get_table_name('scans');
				// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Write to plugin-owned tables; no WordPress data API or cached result applies.
				$wpdb->update(
					$scans_table,
					['status' => 'failed'],
					['id' => $row->scan_id],
					['%s'],
					['%d']
				);
				// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			}

			return rest_ensure_response([
				'item' => null,
				'message' => 'Skipped invalid post: ' . ($post ? 'not published' : 'does not exist'),
				'skipped' => true,
			]);
		}

		// Generate a token for this item
		$token = \wp_generate_password(32, false);
		$expiry_seconds = (int) \get_option('cleara11y_scan_token_expiry', 300);
		$expires_at = gmdate('Y-m-d H:i:s', time() + $expiry_seconds);

		// Store token data
		$token_data = [
			'scan_id' => $row->scan_id,
			'scan_item_id' => $row->id,
			'post_id' => $row->post_id,
			'created_at' => \current_time('mysql'),
			'expires_at' => $expires_at,
		];

		\update_option(
			'cleara11y_scan_token_' . $token,
			$token_data,
			false
		);

		// Get scan URL (add parameter to disable frontend highlighting during scan)
		$scan_url = \add_query_arg(
			['cleara11y_scanning' => '1'],
			\get_permalink($row->post_id)
		);

		return rest_ensure_response([
			'item' => [
				'id' => $row->id,
				'scan_id' => $row->scan_id,
				'post_id' => $row->post_id,
				'post_title' => $row->post_title,
				'post_url' => $row->post_url,
			],
			'token' => $token,
			'scan_url' => $scan_url,
			'expires_at' => $expires_at,
		]);
	}

	/**
	 * Cancel a queued scan.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response
	 */
	public function cancel_queue_scan(\WP_REST_Request $request): \WP_REST_Response|\WP_Error {
		$scan_id = (int) $request->get_param('scan_id');

		$scan = Scan_Repository::get_by_id($scan_id);

		if (!$scan) {
			return rest_ensure_response(
				new \WP_Error('scan_not_found', 'Scan not found.', ['status' => 404])
			);
		}

		// Only allow cancelling pending or in_progress scans
		if (!in_array($scan->status, ['pending', 'in_progress'], true)) {
			return rest_ensure_response(
				new \WP_Error('invalid_status', 'Scan cannot be cancelled.', ['status' => 400])
			);
		}

		if (! \ClearA11y\Services\Scan_Orchestrator::cancel_scan($scan_id)) {
			return rest_ensure_response(
				new \WP_Error('cancel_failed', 'Scan could not be cancelled.', ['status' => 500])
			);
		}

		return rest_ensure_response([
			'message' => 'Scan cancelled successfully.',
		]);
	}

	/**
	 * Get canonical issue occurrences for the explorer.
	 *
	 * @param \WP_REST_Request $request REST request.
	 * @return \WP_REST_Response|\WP_Error Response.
	 */
	public function get_issue_occurrences(\WP_REST_Request $request) {
		$scan_id = absint($request->get_param('scan_id'));
		$page_id = absint($request->get_param('page_id'));

		$scan = null;
		if ($scan_id > 0) {
			$scan = Scan_Repository::get_by_id($scan_id);
			if (! $scan) {
				return new \WP_Error('scan_not_found', __('Scan not found.', 'cleara11y'), ['status' => 404]);
			}
		}

		if ($page_id > 0 && ! get_post($page_id)) {
			return new \WP_Error('page_not_found', __('Page not found.', 'cleara11y'), ['status' => 404]);
		}

		$args = [
			'status' => $scan_id > 0 ? 'all' : ($request->get_param('status') ?: 'active'),
			'severity' => $request->get_param('severity') ?: '',
			'finding_type' => $request->get_param('finding_type') ?: '',
			'rule_id' => sanitize_key((string) $request->get_param('rule_id')),
			'post_id' => $page_id,
			'scan_id' => $scan_id,
			'search' => sanitize_text_field((string) $request->get_param('search')),
			'group_by' => $request->get_param('group_by') ?: 'page',
			'sort' => $request->get_param('sort') ?: 'severity',
			'page' => max(1, absint($request->get_param('page'))),
			'per_page' => min(100, max(1, absint($request->get_param('per_page')) ?: 20)),
		];

		$result = Issue_Repository::query_explorer($args);
		$result['context'] = [
			'mode' => $scan ? 'scan' : 'live',
			'status' => $scan ? null : $args['status'],
			'rule' => $args['rule_id'] ? [
				'id' => $args['rule_id'],
				'label' => $this->get_rule_label($args['rule_id']),
			] : null,
			'page' => $page_id ? [
				'id' => $page_id,
				/* translators: Placeholder is the scan or page identifier. */
				'label' => get_the_title($page_id) ?: sprintf(__('Page #%d', 'cleara11y'), $page_id),
			] : null,
			'scan' => $scan ? $this->format_explorer_scan_context($scan) : null,
		];

		return rest_ensure_response($result);
	}

	/**
	 * Get one issue occurrence.
	 *
	 * @param \WP_REST_Request $request REST request.
	 * @return \WP_REST_Response|\WP_Error Response.
	 */
	public function get_issue_occurrence(\WP_REST_Request $request) {
		$issue = Issue_Repository::get_explorer_occurrence(absint($request->get_param('id')));
		if (! $issue) {
			return new \WP_Error('occurrence_not_found', __('Issue occurrence not found.', 'cleara11y'), ['status' => 404]);
		}

		$issue['inspect_url'] = null;
		if (! empty($issue['selector']) && get_option('cleara11y_enable_frontend_highlighting', true)) {
			$issue['inspect_url'] = \ClearA11y\Frontend\Highlighter::get_highlight_url(
				$issue['id'],
				$issue['page']['id']
			);
		}

		return rest_ensure_response(['occurrence' => $issue]);
	}

	/**
	 * Get explorer filter options.
	 *
	 * @param \WP_REST_Request $request REST request.
	 * @return \WP_REST_Response Response.
	 */
	public function get_issue_filter_options(\WP_REST_Request $request): \WP_REST_Response {
		$options = Issue_Repository::get_explorer_filter_options(
			(string) $request->get_param('type'),
			sanitize_text_field((string) $request->get_param('search'))
		);
		return rest_ensure_response(['options' => $options]);
	}

	/**
	 * Format scan context for the explorer.
	 *
	 * @param \ClearA11y\Models\Scan $scan Scan.
	 * @return array Context.
	 */
	private function format_explorer_scan_context(\ClearA11y\Models\Scan $scan): array {
		$latest_completed = Scan_Repository::get_all([
			'status' => 'completed',
			'limit' => 1,
			'orderby' => 'completed_at',
			'order' => 'DESC',
		]);
		$latest_id = ! empty($latest_completed) ? (int) $latest_completed[0]->id : 0;

		return [
			'id' => $scan->id,
			/* translators: Placeholder is the scan or page identifier. */
			'label' => $scan->scan_name ?: sprintf(__('Scan #%d', 'cleara11y'), $scan->id),
			'status' => $scan->status,
			'date' => $scan->completed_at ?: ($scan->started_at ?: $scan->created_at),
			'is_historical' => 'completed' === $scan->status && $latest_id > 0 && $latest_id !== $scan->id,
			'is_provisional' => in_array($scan->status, ['pending', 'in_progress'], true),
		];
	}

	/**
	 * Get a human-readable label for a stored rule.
	 *
	 * @param string $rule_id Rule ID.
	 * @return string Label.
	 */
	private function get_rule_label(string $rule_id): string {
		global $wpdb;
		$table = \ClearA11y\Database\Schema::get_table_name('issues');
		// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state; Schema-owned identifiers and fixed SQL fragments; variable values are prepared separately.
		$label = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT help_text FROM `{$table}` WHERE rule_id = %s AND help_text IS NOT NULL ORDER BY id DESC LIMIT 1",
				$rule_id
			)
		);
		// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return $label ?: $rule_id;
	}

	/**
	 * Get issues list with filters and pagination.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response
	 */
	public function get_issues_list(\WP_REST_Request $request): \WP_REST_Response {
		global $wpdb;

		if (! \ClearA11y\Database\Exception_Schema::tables_exist()) {
			\ClearA11y\Database\Exception_Schema::create_tables();
		}

		$severity = $request->get_param('severity');
		$status = $request->get_param('status') ?? 'active';
		$search = $request->get_param('search');
		$page = max(1, (int) ($request->get_param('page') ?? 1));
		$per_page = max(1, min(100, (int) ($request->get_param('per_page') ?? 20)));
		$offset = ($page - 1) * $per_page;

		$issues_table = \ClearA11y\Database\Schema::get_table_name('issues');
		$scan_items_table = \ClearA11y\Database\Schema::get_table_name('scan_items');
		$matches_table = \ClearA11y\Database\Exception_Schema::get_table_name('issue_exception_matches');
		$rules_table = \ClearA11y\Database\Exception_Schema::get_table_name('exception_rules');
		$active_exception_join = "
			LEFT JOIN (
				SELECT DISTINCT vm.violation_id
				FROM `{$matches_table}` vm
				INNER JOIN `{$rules_table}` ir ON vm.exception_rule_id = ir.id
				WHERE ir.status = 'active'
					AND vm.match_action = 'suppressed'
					AND (ir.expires_at IS NULL OR ir.expires_at > NOW())
			) active_exceptions ON i.id = active_exceptions.violation_id";

		// Build WHERE clause
		$where = ['1=1'];
		$where_params = [];

		if (!empty($severity)) {
			$where[] = 'i.severity = %s';
			$where_params[] = $severity;
		}

		// Filter by status (active/exceptions/all)
		if ($status === 'active') {
			// Show only issues without active exception matches
			$where[] = 'active_exceptions.violation_id IS NULL';
		} elseif ($status === 'exception') {
			// Show only issues with active exception matches
			$where[] = 'active_exceptions.violation_id IS NOT NULL';
		}
		// 'all' doesn't filter

		if (!empty($search)) {
			$where[] = '(i.rule_id LIKE %s OR i.message LIKE %s OR si.post_title LIKE %s OR si.post_url LIKE %s)';
			$search_term = '%' . $wpdb->esc_like($search) . '%';
			$where_params[] = $search_term;
			$where_params[] = $search_term;
			$where_params[] = $search_term;
			$where_params[] = $search_term;
		}

		$where_clause = implode(' AND ', $where);

		// Get total count
		$count_query = "SELECT COUNT(DISTINCT i.id) FROM `{$issues_table}` i
					   INNER JOIN `{$scan_items_table}` si ON i.scan_item_id = si.id
					   {$active_exception_join}
					   WHERE {$where_clause}";
		// @phpstan-ignore-next-line
		$total = !empty($where_params)
			? (int) $wpdb->get_var($wpdb->prepare($count_query, ...$where_params)) // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state.
			: (int) $wpdb->get_var($count_query); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.PreparedSQL.NotPrepared -- Reviewed: fixed SQL fragments and schema table names; variable values are prepared.

		// Get issues
		$query = "SELECT i.*, si.post_title, si.post_url,
					CASE WHEN active_exceptions.violation_id IS NOT NULL THEN 1 ELSE 0 END as is_exception
				 FROM `{$issues_table}` i
				 INNER JOIN `{$scan_items_table}` si ON i.scan_item_id = si.id
				 {$active_exception_join}
				 WHERE {$where_clause}
				 ORDER BY is_exception ASC, FIELD(i.severity, 'critical', 'moderate', 'minor'), i.id DESC
				 LIMIT %d OFFSET %d";

		$where_params[] = $per_page;
		$where_params[] = $offset;

		// @phpstan-ignore-next-line
		$issues = $wpdb->get_results($wpdb->prepare($query, ...$where_params)); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state.

		return rest_ensure_response([
			'data' => $issues,
			'total' => $total,
			'page' => $page,
			'per_page' => $per_page,
			'total_pages' => ceil($total / $per_page),
		]);
	}

	/**
	 * Get issues statistics.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response
	 */
	public function get_issues_stats(\WP_REST_Request $request): \WP_REST_Response {
		global $wpdb;

		if (! \ClearA11y\Database\Exception_Schema::tables_exist()) {
			\ClearA11y\Database\Exception_Schema::create_tables();
		}

		$issues_table = \ClearA11y\Database\Schema::get_table_name('issues');
		$matches_table = \ClearA11y\Database\Exception_Schema::get_table_name('issue_exception_matches');
		$rules_table = \ClearA11y\Database\Exception_Schema::get_table_name('exception_rules');
		$active_exception_join = "
			LEFT JOIN (
				SELECT DISTINCT vm.violation_id
				FROM `{$matches_table}` vm
				INNER JOIN `{$rules_table}` ir ON vm.exception_rule_id = ir.id
				WHERE ir.status = 'active'
					AND vm.match_action = 'suppressed'
					AND (ir.expires_at IS NULL OR ir.expires_at > NOW())
			) active_exceptions ON i.id = active_exceptions.violation_id";

		// Get raw and actionable counts while keeping scan evidence unchanged.
		// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state; Schema-owned identifiers and fixed SQL fragments; variable values are prepared separately.
		$counts = $wpdb->get_results(
			"SELECT
				SUM(CASE WHEN i.severity = 'critical' AND active_exceptions.violation_id IS NULL THEN 1 ELSE 0 END) as critical,
				SUM(CASE WHEN i.severity = 'moderate' AND active_exceptions.violation_id IS NULL THEN 1 ELSE 0 END) as moderate,
				SUM(CASE WHEN i.severity = 'minor' AND active_exceptions.violation_id IS NULL THEN 1 ELSE 0 END) as minor,
				SUM(CASE WHEN active_exceptions.violation_id IS NULL THEN 1 ELSE 0 END) as active,
				SUM(CASE WHEN active_exceptions.violation_id IS NOT NULL THEN 1 ELSE 0 END) as exception,
				COUNT(*) as total
			FROM `{$issues_table}` i
			{$active_exception_join}",
			ARRAY_A
		);
		// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		$stats = $counts[0] ?? [
			'critical' => 0,
			'moderate' => 0,
			'minor' => 0,
			'active' => 0,
			'exception' => 0,
			'total' => 0,
		];

		// Convert to integers
		foreach ($stats as $key => $value) {
			$stats[$key] = (int) $value;
		}

		return rest_ensure_response($stats);
	}

	/**
	 * Get pages list with accessibility scores and issues.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response
	 */
	public function get_pages_list(\WP_REST_Request $request): \WP_REST_Response {
		global $wpdb;

		$post_type = $request->get_param('post_type') ?? 'page';
		$status = $request->get_param('status') ?? 'all';
		$severity = $request->get_param('severity');
		$search = $request->get_param('search');
		$orderby = $request->get_param('orderby') ?? 'scanned_date';
		$order = $request->get_param('order') ?? 'desc';
		$page = max(1, (int) ($request->get_param('page') ?? 1));
		$per_page = max(1, min(100, (int) ($request->get_param('per_page') ?? 20)));
		$offset = ($page - 1) * $per_page;

		$scan_items_table = \ClearA11y\Database\Schema::get_table_name('scan_items');
		$scans_table = \ClearA11y\Database\Schema::get_table_name('scans');
		$issues_table = \ClearA11y\Database\Schema::get_table_name('issues');
		$posts_table = $wpdb->posts;

		// Build WHERE clause
		$where = ['p.post_type = %s', "p.post_status = 'publish'"];
		$where_params = [$post_type];

		// Filter by scan status
		if ($status === 'scanned') {
			$where[] = 'si.status = "completed"';
		} elseif ($status === 'unscanned') {
			$where[] = 'si.id IS NULL';
		}

		// Search by title or URL
		if (!empty($search)) {
			$where[] = '(p.post_title LIKE %s OR si.post_url LIKE %s)';
			$search_term = '%' . $wpdb->esc_like($search) . '%';
			$where_params[] = $search_term;
			$where_params[] = $search_term;
		}

		$where_clause = implode(' AND ', $where);

		// Get total count
		$count_query = "SELECT COUNT(DISTINCT p.ID)
					   FROM `{$posts_table}` p
					   LEFT JOIN `{$scan_items_table}` si ON p.ID = si.post_id AND si.status = 'completed'
					   LEFT JOIN `{$scans_table}` s ON si.scan_id = s.id AND s.status = 'completed'
					   WHERE {$where_clause}";

		if (!empty($where_params)) {
			$total = (int) $wpdb->get_var($wpdb->prepare($count_query, ...$where_params)); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state.
		} else {
			$total = (int) $wpdb->get_var($count_query); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state.
		}

		// Get pages with latest scan_item info
		$pages_query = "SELECT p.ID as post_id,
						p.post_title,
						p.post_type,
						si.id as scan_item_id,
						si.status as scan_status,
						si.post_url,
						si.scanned_at,
						si.error_message
					 FROM `{$posts_table}` p
					 LEFT JOIN `{$scan_items_table}` si ON p.ID = si.post_id AND si.status = 'completed'
					 LEFT JOIN `{$scans_table}` s ON si.scan_id = s.id AND s.status = 'completed'
					 WHERE {$where_clause}
					 ORDER BY p.post_title ASC
					 LIMIT %d OFFSET %d";

		$params = [...$where_params, $per_page, $offset];

		if (!empty($params)) {
			$pages = $wpdb->get_results($wpdb->prepare($pages_query, ...$params)); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state.
		} else {
			$pages = $wpdb->get_results($pages_query); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state.
		}

		// Calculate score and format results
		$formatted_pages = [];
		foreach ($pages as $page) {
			// Get actual issue counts from issues table.
			$counts = [
				'total' => 0,
				'critical' => 0,
				'moderate' => 0,
				'minor' => 0,
			];

			if ($page->scan_item_id && $page->scan_status === 'completed') {
				// Count issues from the latest scan_item.
				\cleara11y_debug_log('ClearA11y Pages List: Querying issues for post_id: ' . $page->post_id . ', scan_item_id: ' . $page->scan_item_id);
				// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state; Schema-owned identifiers and fixed SQL fragments; variable values are prepared separately.
				$issue_counts = $wpdb->get_results(
					$wpdb->prepare(
						"SELECT severity, COUNT(*) as count
						 FROM `{$issues_table}`
						 WHERE scan_item_id = %d
						 GROUP BY severity",
						$page->scan_item_id
					),
					ARRAY_A
				);
				// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

				foreach ($issue_counts as $row) {
					$counts[$row['severity']] = (int) $row['count'];
					$counts['total'] += (int) $row['count'];
			\cleara11y_debug_log(sprintf('ClearA11y Pages List: post_id %d, scan_item_id %d, counts: total=%d critical=%d moderate=%d minor=%d',
				$page->post_id, $page->scan_item_id, $counts['total'], $counts['critical'], $counts['moderate'], $counts['minor']));
				}
			}

			$score = 100;
			if ($counts['total'] > 0) {
				$score = max(0, 100 - ($counts['critical'] * 10) - ($counts['moderate'] * 5) - ($counts['minor'] * 2));
			}

			$formatted_pages[] = [
				'post_id' => (int) $page->post_id,
				'post_title' => $page->post_title,
				'post_type' => $page->post_type,
				'post_url' => $page->post_url ?: get_permalink($page->post_id),
				'scan_status' => $page->scan_status ?: 'unscanned',
				'score' => $score,
				'issues' => [
					'total' => $counts['total'],
					'critical' => $counts['critical'],
					'moderate' => $counts['moderate'],
					'minor' => $counts['minor'],
				],
				'scanned_at' => $page->scanned_at,
				'error_message' => $page->error_message,
			];
		}

		// Sort after we have all the data
		$formatted_pages = $this->sort_pages_list($formatted_pages, $orderby, $order);

		return rest_ensure_response([
			'data' => $formatted_pages,
			'total' => $total,
			'page' => $page,
			'per_page' => $per_page,
			'total_pages' => ceil($total / $per_page),
		]);
	}


	/**
	 * Sort pages list by specified criteria.
	 *
	 * @param array  $pages  Pages array to sort.
	 * @param string $orderby Field to order by.
	 * @param string $order   Sort direction (asc/desc).
	 * @return array Sorted pages.
	 */
	private function sort_pages_list(array $pages, string $orderby, string $order): array {
		usort($pages, function($a, $b) use ($orderby, $order) {
			$a_val = null;
			$b_val = null;

			switch ($orderby) {
				case 'title':
					$a_val = $a['post_title'] ?? '';
					$b_val = $b['post_title'] ?? '';
					break;
				case 'score':
					$a_val = $a['score'] ?? 100;
					$b_val = $b['score'] ?? 100;
					break;
				case 'issues':
					$a_val = $a['issues']['total'] ?? 0;
					$b_val = $b['issues']['total'] ?? 0;
					break;
				case 'scanned_date':
				default:
					$a_val = $a['scanned_at'] ?? '1970-01-01';
					$b_val = $b['scanned_at'] ?? '1970-01-01';
					break;
			}

			$direction = strtolower($order) === 'asc' ? 1 : -1;

			if ($a_val === $b_val) {
				// Secondary sort by title
				return strnatcasecmp($a['post_title'] ?? '', $b['post_title'] ?? '') * $direction;
			}

			if (is_string($a_val)) {
				return strcmp($a_val, $b_val) * $direction;
			}

			// Compare numbers without spaceship operator (PHP 5.x compatible)
			if ($a_val < $b_val) {
				return -1 * $direction;
			} elseif ($a_val > $b_val) {
				return 1 * $direction;
			}
			return 0;
		});

		return $pages;
	}

		/**
		 * Get issue types grouped by rule.
		 *
		 * @param \WP_REST_Request $request REST request object.
		 * @return \WP_REST_Response
		 */
	public function get_issue_types(\WP_REST_Request $request): \WP_REST_Response {
		global $wpdb;

		$severity = $request->get_param('severity');
		$search = $request->get_param('search');

		$issues_table = \ClearA11y\Database\Schema::get_table_name('issues');

		// Build WHERE clause
		$where = ['1=1'];
		$where_params = [];

		// Filter by severity
		if (!empty($severity)) {
			$where[] = 'severity = %s';
			$where_params[] = $severity;
		}

		// Search
		if (!empty($search)) {
			$where[] = '(rule_id LIKE %s OR message LIKE %s)';
			$where_params[] = '%' . $wpdb->esc_like($search) . '%';
			$where_params[] = '%' . $wpdb->esc_like($search) . '%';
		}

		$where_clause = 'WHERE ' . implode(' AND ', $where);

		// Get issue types grouped by rule
		$query = "SELECT
				rule_id,
				rule_type,
				severity,
				message,
				help_url,
				COUNT(*) as issue_count,
				COUNT(DISTINCT post_id) as page_count,
				MAX(created_at) as last_found
			FROM `{$issues_table}`
			{$where_clause}
			GROUP BY rule_id, rule_type, severity, message
			ORDER BY FIELD(severity, 'critical', 'moderate', 'minor'), issue_count DESC";
		if (!empty($where_params)) {
			$query = $wpdb->prepare($query, ...$where_params); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Reviewed: fixed SQL fragments and schema table names; variable values are prepared.
		}

		$issue_types = $wpdb->get_results($query); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state.

		// Get counts for status tabs
		$count_query = "SELECT
				COUNT(*) as total_issues
			FROM `{$issues_table}`
			{$where_clause}";
		if (!empty($where_params)) {
			$count_query = $wpdb->prepare($count_query, ...$where_params); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Reviewed: fixed SQL fragments and schema table names; variable values are prepared.
		}

		$counts = $wpdb->get_row($count_query, ARRAY_A); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state.

		return rest_ensure_response([
			'issue_types' => $issue_types,
			'counts' => [
				'all' => (int) ($counts['total_issues'] ?? 0),
			],
		]);
	}

	/**
	 * Get pages that have a specific issue type.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response
	 */
	public function get_issue_type_pages(\WP_REST_Request $request): \WP_REST_Response {
		global $wpdb;

		$rule_id = $request->get_param('rule_id');
		$page = max(1, (int) ($request->get_param('page') ?? 1));
		$per_page = max(1, min(100, (int) ($request->get_param('per_page') ?? 20)));
		$offset = ($page - 1) * $per_page;

		$issues_table = \ClearA11y\Database\Schema::get_table_name('issues');
		$scan_items_table = \ClearA11y\Database\Schema::get_table_name('scan_items');

		// Get total count
		// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state; Schema-owned identifiers and fixed SQL fragments; variable values are prepared separately.
		$total = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT i.post_id)
				FROM `{$issues_table}` i
				WHERE i.rule_id = %s",
				$rule_id
			)
		);
		// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		// Get pages with this issue
		// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state; Schema-owned identifiers and fixed SQL fragments; variable values are prepared separately.
		$pages = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT
					DISTINCT i.post_id,
					si.post_title,
					si.post_url,
					COUNT(*) as issue_count,
					COUNT(*) as active_count
				FROM `{$issues_table}` i
				INNER JOIN `{$scan_items_table}` si ON i.scan_item_id = si.id
				WHERE i.rule_id = %s
				GROUP BY i.post_id, si.post_title, si.post_url
				ORDER BY active_count DESC
				LIMIT %d OFFSET %d",
				$rule_id,
				$per_page,
				$offset
			)
		);
		// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return rest_ensure_response([
			'pages' => $pages,
			'total' => (int) $total,
			'page' => $page,
			'per_page' => $per_page,
			'total_pages' => ceil($total / $per_page),
		]);
	}

	/**
	 * Lease jobs for parallel processing.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response
	 */
	public function lease_jobs(\WP_REST_Request $request): \WP_REST_Response {
		$worker_id = sanitize_text_field($request->get_param('workerId') ?? wp_generate_uuid_v4());
		$limit = (int) ($request->get_param('limit') ?? 2);
		$lease_seconds = (int) ($request->get_param('leaseSeconds') ?? 180);
		$site_id = get_current_blog_id();

		\cleara11y_debug_log(sprintf('[ClearA11y] lease_jobs called: worker=%s, limit=%d, site=%d',
			$worker_id, $limit, $site_id));

		// Expire stuck jobs first
		$expired = Job_Repository::expire_stuck_jobs();
		if ($expired > 0) {
			\cleara11y_debug_log('[ClearA11y] lease_jobs: Expired ' . $expired . ' stuck jobs');
		}

		// Lease pending jobs
		$jobs = Job_Repository::lease_jobs($limit, $site_id, $worker_id, $lease_seconds);
		foreach ($jobs as &$job) {
			$scan_item = Scan_Item_Repository::get_by_scan_and_post((int) $job['scan_id'], (int) $job['post_id']);
			if (! $scan_item) {
				\cleara11y_debug_log(
					sprintf(
						'ClearA11y ERROR: Cannot create attribution token for leased job. job_id=%d scan_id=%d post_id=%d',
						(int) $job['id'],
						(int) $job['scan_id'],
						(int) $job['post_id']
					)
				);
				continue;
			}

			$token = Scan_Token_Manager::generate_existing_token(
				(int) $job['scan_id'],
				(int) $scan_item->id,
				(int) $job['post_id'],
				(string) $job['url']
			);
			$job['url'] = $token['scan_url'];
		}
		unset($job);

		\cleara11y_debug_log(sprintf('[ClearA11y] lease_jobs: Leased %d jobs for worker %s',
			count($jobs), $worker_id));

		return rest_ensure_response([
			'workerId' => $worker_id,
			'jobs' => $jobs,
			'leased' => count($jobs),
		]);
	}

	/**
	 * Extend lease for a job (heartbeat).
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response
	 */
	public function job_heartbeat(\WP_REST_Request $request): \WP_REST_Response|\WP_Error {
		$job_id = (int) $request->get_param('jobId');
		$lease_token = $request->get_param('leaseToken');
		$lease_seconds = (int) ($request->get_param('leaseSeconds') ?? 180);

		$result = Job_Repository::heartbeat($job_id, $lease_token, $lease_seconds);

		if ($result === false) {
			return rest_ensure_response(
				new \WP_Error('heartbeat_failed', 'Invalid job ID, lease token, or job not active.', ['status' => 403])
			);
		}

		return rest_ensure_response($result);
	}

	/**
	 * Complete a job (success or failure).
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function complete_job(\WP_REST_Request $request): \WP_REST_Response|\WP_Error {
		global $wpdb;

		$job_id = (int) $request->get_param('jobId');
		$lease_token = $request->get_param('leaseToken');
		$status = $request->get_param('status'); // 'done' or 'failed'
		$result_json = $request->get_param('resultJson');
		$error = $request->get_param('error');
		$error = is_string($error) ? sanitize_textarea_field($error) : null;
		if (! in_array($status, ['done', 'failed'], true) || ! is_string($lease_token)) {
			return new \WP_Error('invalid_job_result', 'Invalid job result status or lease token.', ['status' => 400]);
		}
		$request_bytes = strlen($request->get_body());

		if ($request_bytes > self::MAX_SCAN_RESULT_REQUEST_BYTES) {
			\cleara11y_debug_log(
				sprintf(
					'ClearA11y ERROR: Rejected oversized job result. job_id=%d body_bytes=%d limit_bytes=%d',
					$job_id,
					$request_bytes,
					self::MAX_SCAN_RESULT_REQUEST_BYTES
				)
			);
			return rest_ensure_response(
				new \WP_Error(
					'scan_results_too_large',
					'The scan evidence payload is too large to store safely. Reduce the scan scope or increase the server request limits.',
					['status' => 413]
				)
			);
		}

		// Get job first for additional processing
		$job = Job_Repository::get_by_id($job_id);

		if (!$job || $job->lease_token !== $lease_token) {
			return rest_ensure_response(
				new \WP_Error('job_not_found', 'Invalid job ID or lease token.', ['status' => 404])
			);
		}

		$results = null;
		if ('done' === $status) {
			$results = \ClearA11y\Services\Scan_Result_Sanitizer::sanitize($result_json);
			if (is_wp_error($results)) {
				return $results;
			}
			$result_json = wp_json_encode($results, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
			$evidence = is_array($results) ? ($results['evidence'] ?? null) : null;
			$finding_nodes = is_array($results) ? self::count_finding_nodes($results) : 0;

			if (
				! is_array($results)
				|| JSON_ERROR_NONE !== json_last_error()
				|| ! isset($results['violations'], $results['incomplete'])
				|| ! is_array($results['violations'])
				|| ! is_array($results['incomplete'])
				|| ! is_array($evidence)
			) {
				\cleara11y_debug_log(
					sprintf(
						'ClearA11y ERROR: Rejected malformed job result. job_id=%d json_error=%s',
						$job_id,
						json_last_error_msg()
					)
				);
				return rest_ensure_response(
					new \WP_Error(
						'invalid_scan_results',
						'The browser returned malformed scan results. Run the scan again.',
						['status' => 400]
					)
				);
			}

			if (count($evidence) < $finding_nodes) {
				\cleara11y_debug_log(
					sprintf(
						'ClearA11y ERROR: Rejected incomplete job evidence. job_id=%d finding_nodes=%d evidence_records=%d',
						$job_id,
						$finding_nodes,
						count($evidence)
					)
				);
				return rest_ensure_response(
					new \WP_Error(
						'incomplete_scan_evidence',
						'The browser did not return evidence for every accessibility finding. Run the scan again and check the browser console if this continues.',
						['status' => 422]
					)
				);
			}
		}

		// Complete the job using repository
		$completed = Job_Repository::complete($job_id, $lease_token, $status, $result_json, $error);

		if (!$completed) {
			return rest_ensure_response(
				new \WP_Error('complete_failed', 'Failed to complete job.', ['status' => 500])
			);
		}

		$scan_items_table = \ClearA11y\Database\Schema::get_table_name('scan_items');
		// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state; Schema-owned identifiers and fixed SQL fragments; variable values are prepared separately.
		$scan_item = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM `{$scan_items_table}` WHERE post_id = %d AND scan_id = %d LIMIT 1",
				$job->post_id,
				$job->scan_id
			),
			ARRAY_A
		);
		// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		// Additional processing for completed jobs.
		if ($status === 'done' && $result_json && $scan_item) {
			if ($results && isset($results['violations'])) {
				// Store results via Scan_Results_Processor.
				$results_processor = new Scan_Results_Processor();
				$results_processor->process_results(
					$scan_item['id'],
					$results,
					$results['evidence'] ?? []
				);
			}
		} elseif ($status === 'failed' && $scan_item) {
			Scan_Results_Processor::handle_error(
				(int) $scan_item['id'],
				$error ?: 'Scan job failed.'
			);
		}

		// CRITICAL: Check if scan is complete and update status
		$this->check_and_complete_scan($job->scan_id);

		return rest_ensure_response([
			'ok' => true,
		]);
	}

	/**
	 * Count axe finding nodes that require evidence records.
	 *
	 * @param array $results Axe scan results.
	 * @return int
	 */
	private static function count_finding_nodes(array $results): int {
		$count = 0;

		foreach (['violations', 'incomplete'] as $result_type) {
			foreach (($results[$result_type] ?? []) as $finding) {
				if (is_array($finding) && isset($finding['nodes']) && is_array($finding['nodes'])) {
					$count += count($finding['nodes']);
				}
			}
		}

		return $count;
	}

	/**
	 * Check if all jobs for a scan are complete and update scan status.
	 *
	 * @param int $scan_id Scan ID.
	 * @return void
	 */
	private function check_and_complete_scan(int $scan_id): void {
		global $wpdb;

		$jobs_table = \ClearA11y\Database\Schema::get_table_name('scan_jobs');
		$scans_table = \ClearA11y\Database\Schema::get_table_name('scans');

		// Check if there are any pending or active jobs
		// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state; Schema-owned identifiers and fixed SQL fragments; variable values are prepared separately.
		$pending_count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM `{$jobs_table}`
				WHERE scan_id = %d
				AND status IN ('pending', 'active')",
				$scan_id
			)
		);
		// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		if ($pending_count == 0) {
			// All jobs are complete - update scan status
			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Write to plugin-owned tables; no WordPress data API or cached result applies.
			$updated = $wpdb->update(
				$scans_table,
				[
					'status' => 'completed',
					'completed_at' => current_time('mysql', true),
				],
				[
					'id' => $scan_id,
					'status' => 'in_progress',
				],
				['%s', '%s'],
				['%d', '%s']
			);
			// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

			if ($updated) {
				\cleara11y_debug_log(sprintf('[ClearA11y] Scan %d marked as completed', $scan_id));
			}
		}
	}

	/**
	 * Update parent scan progress after job completion.
	 *
	 * @param int $scan_id Scan ID.
	 * @return void
	 */
	private function update_scan_progress(int $scan_id): void {
		global $wpdb;

		$scans_table = \ClearA11y\Database\Schema::get_table_name('scans');
		$scan_items_table = \ClearA11y\Database\Schema::get_table_name('scan_items');

		// Get scan item counts
		// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state; Schema-owned identifiers and fixed SQL fragments; variable values are prepared separately.
		$counts = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT
					COUNT(*) as total,
					SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
					SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed,
					SUM(total_issues) as total_issues,
					SUM(critical_issues) as critical_issues,
					SUM(moderate_issues) as moderate_issues,
					SUM(minor_issues) as minor_issues
				FROM `{$scan_items_table}`
				WHERE scan_id = %d",
				$scan_id
			),
			ARRAY_A
		);
		// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		if ($counts) {
			$total = (int) $counts['total'];
			$completed = (int) $counts['completed'];
			$failed = (int) $counts['failed'];
			$finished = $completed + $failed;

			// Update scan with progress
			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Write to plugin-owned tables; no WordPress data API or cached result applies.
			$wpdb->update(
				$scans_table,
				[
					'scanned_items' => $finished,
					'total_issues' => (int) $counts['total_issues'],
					'critical_issues' => (int) $counts['critical_issues'],
					'moderate_issues' => (int) $counts['moderate_issues'],
					'minor_issues' => (int) $counts['minor_issues'],
					'status' => ($finished >= $total) ? 'completed' : 'in_progress',
					'completed_at' => ($finished >= $total) ? current_time('mysql', true) : null,
				],
				['id' => $scan_id],
				['%d', '%d', '%d', '%d', '%d', '%s', '%s'],
				['%d']
			);
			// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		}
	}

	/**
	 * Get job queue statistics.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response
	 */
	public function get_job_stats(\WP_REST_Request $request): \WP_REST_Response {
		// Check if we should filter by current scan
		$scan_id = $request->get_param('scan_id');

		if ($scan_id) {
			$stats = Job_Repository::get_stats_by_scan((int) $scan_id);
		} else {
			$stats = Job_Repository::get_stats();
		}

		// Add total for backward compatibility
		$stats['total'] = $stats['pending'] + $stats['active'] + $stats['completed'] + $stats['failed'];

		return rest_ensure_response($stats);
	}

	/**
	 * Get scan stats (job counts for a specific scan).
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response
	 */
	public function get_scan_stats(\WP_REST_Request $request): \WP_REST_Response|\WP_Error {
		$scan_id = (int) $request->get_param('id');

		if (!$scan_id) {
			return new \WP_Error('invalid_scan', 'Invalid scan ID', ['status' => 400]);
		}

		$stats = Job_Repository::get_stats_by_scan($scan_id);

		// Add total for convenience
		$stats['total'] = $stats['pending'] + $stats['active'] + $stats['completed'] + $stats['failed'];

		return rest_ensure_response($stats);
	}

	/**
	 * Get active scan (for global scanner auto-resume).
	 * Returns the most recent scan with 'in_progress' status.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response
	 */
	public function get_active_scan(\WP_REST_Request $request): \WP_REST_Response {
		global $wpdb;
		$scans_table = \ClearA11y\Database\Schema::get_table_name('scans');
		$jobs_table = \ClearA11y\Database\Schema::get_table_name('scan_jobs');

		// Log the request for debugging
		\cleara11y_debug_log('[ClearA11y] get_active_scan called');

		// Get the most recent scan with 'in_progress' status
		// This is more reliable - just check scan status, not job status
		// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state; Schema-owned identifiers and fixed SQL fragments; variable values are prepared separately.
		$scan = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT s.* FROM `{$scans_table}` s
				WHERE s.status = 'in_progress'
				ORDER BY s.id DESC
				LIMIT 1"
			)
		);
		// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		if (!$scan) {
			\cleara11y_debug_log('[ClearA11y] get_active_scan: No active scan found');
			return rest_ensure_response([
				'active' => false,
				'scan_id' => null,
			]);
		}

		// Get job statistics for this scan
		$stats = Job_Repository::get_stats_by_scan((int) $scan->id);

		\cleara11y_debug_log(sprintf('[ClearA11y] get_active_scan: Found scan %d - jobs: pending=%d, active=%d, done=%d',
			$scan->id,
			$stats['pending'],
			$stats['active'],
			$stats['completed']
		));

		return rest_ensure_response([
			'active' => true,
			'scan_id' => (int) $scan->id,
			'scan_name' => $scan->scan_name,
			'status' => $scan->status,
			'total_items' => (int) $scan->total_items,
			'scanned_items' => (int) $scan->scanned_items,
			'stats' => $stats,
		]);
	}

	/**
	 * Expire stuck jobs (reset active jobs with expired leases to pending).
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response
	 */
	public function expire_jobs(\WP_REST_Request $request): \WP_REST_Response {
		$force = $request->get_param('force') === true;
		$expired = Job_Repository::expire_stuck_jobs($force);

		return rest_ensure_response([
			'ok' => true,
			'expired' => $expired,
			'forced' => $force,
		]);
	}

	/**
	 * Clean up completed jobs from completed scans.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response
	 */
	public function cleanup_jobs(\WP_REST_Request $request): \WP_REST_Response {
		$cleaned = Job_Repository::cleanup_completed_jobs();

		return rest_ensure_response([
			'ok' => true,
			'cleaned' => $cleaned,
		]);
	}

	/**
	 * Get overview statistics for the dashboard.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response
	 */
	public function get_overview_stats(\WP_REST_Request $request): \WP_REST_Response {
		global $wpdb;

		$latest_scan = \ClearA11y\Database\Scan_Repository::get_latest_active_or_completed();
		$issues_table = \ClearA11y\Database\Schema::get_table_name('issues');
		$scan_items_table = \ClearA11y\Database\Schema::get_table_name('scan_items');

		$stats = [
			'total_critical' => 0,
			'total_moderate' => 0,
			'total_minor' => 0,
			'total_pages' => 0,
		];

		if ($latest_scan) {
			// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state; Schema-owned identifiers and fixed SQL fragments; variable values are prepared separately.
			$issue_counts = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT severity, COUNT(*) as count
					FROM `{$issues_table}`
					WHERE scan_id = %d
					GROUP BY severity",
					$latest_scan->id
				),
				ARRAY_A
			);
			// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

			foreach ($issue_counts as $row) {
				$severity = (string) $row['severity'];
				if (isset($stats['total_' . $severity])) {
					$stats['total_' . $severity] = (int) $row['count'];
				}
			}

			// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state; Schema-owned identifiers and fixed SQL fragments; variable values are prepared separately.
			$stats['total_pages'] = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(DISTINCT post_id)
					FROM `{$scan_items_table}`
					WHERE scan_id = %d AND status = 'completed'",
					$latest_scan->id
				)
			);
			// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		}

		return rest_ensure_response($stats);
	}

	/**
	 * Get recent scans for the dashboard.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response
	 */
	public function get_recent_scans(\WP_REST_Request $request): \WP_REST_Response {
		$limit = min(100, max(1, (int) ($request->get_param('limit') ?? 10)));

		$scans = Scan_Repository::get_all([
			'limit' => $limit,
			'orderby' => 'created_at',
			'order' => 'DESC',
		]);

		// Format scans for JS consumption
		$data = array_map(function($scan) {
			$detail_url = Scans_Page::get_detail_url((int) $scan->id);

			return [
				'id' => $scan->id,
				'scan_type' => $scan->scan_type,
				'status' => $scan->status,
				'total_issues' => (int) $scan->total_issues,
				'created_at' => $scan->created_at,
				'created_at_display' => get_date_from_gmt($scan->created_at, 'M j, Y'),
				'detail_url' => $detail_url,
			];
		}, $scans);

		return rest_ensure_response(['scans' => $data]);
	}
}
