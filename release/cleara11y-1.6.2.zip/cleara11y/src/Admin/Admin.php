<?php
/**
 * Admin Menu
 *
 * Handles admin menu registration.
 *
 * @package ClearA11y
 * @namespace ClearA11y\Admin
 */

namespace ClearA11y\Admin;

if (! defined('ABSPATH')) {
	exit;
}

/**
 * Admin Class
 */
class Admin {

	/**
	 * Single instance of the class.
	 *
	 * @var Admin|null
	 */
	private static ?Admin $instance = null;

	/**
	 * Get the single instance of the class.
	 *
	 * @return Admin
	 */
	public static function get_instance(): Admin {
		if (null === self::$instance) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		add_action('admin_menu', [$this, 'register_menu']);
		add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
		add_action('admin_bar_menu', [$this, 'add_toolbar_indicator'], 999);
		add_filter('set-screen-option', [$this, 'save_screen_option'], 10, 3);

		// AJAX handlers for pages list (fallback if REST API fails)
		add_action('wp_ajax_cleara11y_get_posts', [$this, 'ajax_get_posts']);
		add_action('wp_ajax_cleara11y_get_post_issues', [$this, 'ajax_get_post_issues']);
		add_action('wp_ajax_cleara11y_save_issue_view_option', [$this, 'ajax_save_issue_view_option']);

		// AJAX handlers for global scanner state management
		add_action('wp_ajax_cleara11y_get_scan_state', [$this, 'ajax_get_scan_state']);
		add_action('wp_ajax_cleara11y_save_scan_result', [$this, 'ajax_save_scan_result']);
		add_action('wp_ajax_cleara11y_advance_scan', [$this, 'ajax_advance_scan']);
		add_action('wp_ajax_cleara11y_stop_scan', [$this, 'ajax_stop_scan']);
		add_action('admin_post_cleara11y_cancel_scan', [$this, 'handle_cancel_scan']);
	}

	/**
	 * Cancel an active scan from an admin screen.
	 *
	 * @return void
	 */
	public function handle_cancel_scan(): void {
		if (! current_user_can('manage_options')) {
			wp_die(esc_html__('You do not have permission to cancel scans.', 'cleara11y'));
		}

		$scan_id = isset($_POST['scan_id']) && is_scalar($_POST['scan_id']) ? absint(wp_unslash($_POST['scan_id'])) : 0;
		if (!$scan_id) {
			wp_die(esc_html__('Invalid scan ID.', 'cleara11y'));
		}

		check_admin_referer('cleara11y_cancel_scan_' . $scan_id);
		$cancelled = \ClearA11y\Services\Scan_Orchestrator::cancel_scan($scan_id);
		$redirect = wp_get_referer() ?: admin_url('admin.php?page=cleara11y-scans');
		$redirect = add_query_arg(
			[
				'cleara11y_scan_notice' => $cancelled ? 'cancelled' : 'cancel_failed',
				'cancelled_scan_id' => $scan_id,
			],
			$redirect
		);

		wp_safe_redirect($redirect);
		exit;
	}

	/**
	 * AJAX handler to get posts list (fallback).
	 */
	public function ajax_get_posts(): void {
		check_ajax_referer('cleara11y-nonce', 'nonce');

		if (!current_user_can('edit_posts')) {
			wp_send_json_error(['message' => 'Permission denied']);
		}

		$post_type = isset($_POST['post_type']) && is_scalar($_POST['post_type']) ? sanitize_text_field(wp_unslash($_POST['post_type'])) : 'page';
		$page = isset($_POST['page']) && is_scalar($_POST['page']) ? max(1, intval($_POST['page'])) : 1;
		$per_page = 20;

		$args = [
			'post_type' => $post_type,
			'post_status' => 'publish',
			'posts_per_page' => $per_page,
			'paged' => $page,
			'fields' => 'ids',
		];

		$query = new \WP_Query($args);
		$post_ids = $query->posts;

		$posts = [];
		foreach ($post_ids as $post_id) {
			$post = get_post($post_id);
			$posts[] = [
				'id' => $post_id,
				'title' => [
					'rendered' => $post->post_title,
				],
				'link' => get_permalink($post_id),
			];
		}

		wp_send_json_success([
			'posts' => $posts,
			'total_pages' => $query->max_num_pages,
		]);
	}

	/**
	 * AJAX handler to get post issues (fallback).
	 */
	public function ajax_get_post_issues(): void {
		check_ajax_referer('cleara11y-nonce', 'nonce');

		if (!current_user_can('edit_posts')) {
			wp_send_json_error(['message' => 'Permission denied']);
		}

		$post_id = isset($_POST['post_id']) && is_scalar($_POST['post_id']) ? intval($_POST['post_id']) : 0;

		if (! current_user_can('edit_post', $post_id)) {
			wp_send_json_error(['message' => 'Permission denied'], 403);
		}

		if (!$post_id) {
			wp_send_json_error(['message' => 'Invalid post ID']);
		}

		$counts = \ClearA11y\Database\Issue_Repository::get_post_issue_counts($post_id);

		wp_send_json_success([
			'counts' => $counts,
		]);
	}

	/**
	 * Save one Issues Explorer display preference for the current user.
	 *
	 * @return void
	 */
	public function ajax_save_issue_view_option(): void {
		check_ajax_referer('cleara11y_issue_view_options', 'nonce');

		if (! current_user_can('manage_options')) {
			wp_send_json_error(['message' => __('Permission denied.', 'cleara11y')], 403);
		}

		$option = isset($_POST['option']) && is_scalar($_POST['option']) ? sanitize_key(wp_unslash($_POST['option'])) : '';
		$allowed = array_keys($this->get_issue_view_option_defaults());
		if (! in_array($option, $allowed, true)) {
			wp_send_json_error(['message' => __('Invalid display option.', 'cleara11y')], 400);
		}

		$options = $this->get_issue_view_options();
		$options[$option] = isset($_POST['enabled']) && '1' === sanitize_text_field(wp_unslash($_POST['enabled']));
		update_user_meta(get_current_user_id(), 'cleara11y_issue_view_options', $options);

		wp_send_json_success(['options' => $options]);
	}

	/**
	 * AJAX handler to get current scan state (for global scanner).
	 */
	public function ajax_get_scan_state(): void {
		check_ajax_referer('cleara11y-nonce', 'nonce');

		if (!current_user_can('manage_options')) {
			wp_send_json_error(['message' => 'Permission denied']);
		}

		global $wpdb;
		$scans_table = \ClearA11y\Database\Schema::get_table_name('scans');
		$jobs_table = \ClearA11y\Database\Schema::get_table_name('scan_jobs');

		// Get the most recent active or pending scan
		// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state; Schema-owned identifiers and fixed SQL fragments; variable values are prepared separately.
		$scan = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM `{$scans_table}`
				WHERE status IN ('pending', 'in_progress')
				ORDER BY id DESC
				LIMIT 1"
			)
		);
		// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		if (!$scan) {
			wp_send_json_success([
				'active' => false,
				'scan_id' => null,
			]);
		}

		// Get job statistics
		// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state; Schema-owned identifiers and fixed SQL fragments; variable values are prepared separately.
		$stats = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT
					SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
					SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
					SUM(CASE WHEN status = 'done' THEN 1 ELSE 0 END) as completed,
					SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed
				FROM `{$jobs_table}`
				WHERE scan_id = %d",
				$scan->id
			),
			ARRAY_A
		);
		// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		wp_send_json_success([
			'active' => true,
			'scan_id' => $scan->id,
			'scan_name' => $scan->scan_name,
			'status' => $scan->status,
			'stats' => [
				'pending' => (int) ($stats['pending'] ?? 0),
				'active' => (int) ($stats['active'] ?? 0),
				'completed' => (int) ($stats['completed'] ?? 0),
				'failed' => (int) ($stats['failed'] ?? 0),
			],
		]);
	}

	/**
	 * AJAX handler to save scan result (for global scanner).
	 */
	public function ajax_save_scan_result(): void {
		check_ajax_referer('cleara11y-nonce', 'nonce');

		if (!current_user_can('manage_options')) {
			wp_send_json_error(['message' => 'Permission denied']);
		}

		$job_id = isset($_POST['job_id']) && is_scalar($_POST['job_id']) ? absint(wp_unslash($_POST['job_id'])) : 0;
		$lease_token = isset($_POST['lease_token']) && is_scalar($_POST['lease_token']) ? sanitize_text_field(wp_unslash($_POST['lease_token'])) : '';
		// The shared sanitizer validates source evidence without stripping audited markup.
		$result_json = isset($_POST['result_json']) && is_string($_POST['result_json']) ? wp_unslash($_POST['result_json']) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Passed immediately to Scan_Result_Sanitizer below; HTML evidence is validated as source data.
		$error = isset($_POST['error']) && is_scalar($_POST['error']) ? sanitize_text_field(wp_unslash($_POST['error'])) : '';
		if ('' === $error) {
			$results = \ClearA11y\Services\Scan_Result_Sanitizer::sanitize($result_json);
			if (is_wp_error($results)) {
				wp_send_json_error(['message' => $results->get_error_message()], 400);
			}
			$result_json = wp_json_encode($results, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
		} else {
			$result_json = null;
		}
		if (! $job_id || '' === $lease_token) {
			wp_send_json_error(['message' => 'A job ID and lease token are required.'], 403);
		}

		$request = new \WP_REST_Request('POST', '/cleara11y/v1/jobs/complete');
		$request->set_header('content-type', 'application/json');
		$request->set_body(wp_json_encode([
			'jobId' => $job_id,
			'leaseToken' => $lease_token,
			'status' => '' === $error ? 'done' : 'failed',
			'resultJson' => $result_json,
			'error' => $error,
		]));
		$result = (new \ClearA11y\API\REST_Controller())->complete_job($request);
		if (is_wp_error($result)) {
			wp_send_json_error(['message' => $result->get_error_message()], $result->get_error_data()['status'] ?? 400);
		}
		wp_send_json_success($result->get_data());
	}

	/**
	 * AJAX handler to advance scan (get next job).
	 */
	public function ajax_advance_scan(): void {
		check_ajax_referer('cleara11y-nonce', 'nonce');

		if (!current_user_can('manage_options')) {
			wp_send_json_error(['message' => 'Permission denied']);
		}

		$limit = isset($_POST['limit']) && is_scalar($_POST['limit']) ? min(10, max(1, intval($_POST['limit']))) : 1;
		$worker_id = isset($_POST['worker_id']) && is_scalar($_POST['worker_id']) ? sanitize_text_field(wp_unslash($_POST['worker_id'])) : '';

		$jobs = \ClearA11y\Database\Job_Repository::lease_jobs(
			$limit,
			get_current_blog_id(),
			$worker_id,
			180
		);

		wp_send_json_success([
			'jobs' => $jobs,
		]);
	}

	/**
	 * AJAX handler to stop scan.
	 */
	public function ajax_stop_scan(): void {
		check_ajax_referer('cleara11y-nonce', 'nonce');

		if (!current_user_can('manage_options')) {
			wp_send_json_error(['message' => 'Permission denied']);
		}

		$scan_id = isset($_POST['scan_id']) && is_scalar($_POST['scan_id']) ? intval($_POST['scan_id']) : 0;

		if (!$scan_id) {
			wp_send_json_error(['message' => 'Invalid scan ID']);
		}

		// Reset active jobs to pending
		global $wpdb;
		$jobs_table = \ClearA11y\Database\Schema::get_table_name('scan_jobs');

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Write to plugin-owned tables; no WordPress data API or cached result applies.
		$updated = $wpdb->update(
			$jobs_table,
			[
				'status' => 'pending',
				'lease_token' => null,
				'lease_expires_at' => null,
			],
			[
				'scan_id' => $scan_id,
				'status' => 'active',
			],
			['%s', '%s', '%s'],
			['%d', '%s']
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		wp_send_json_success([
			'ok' => true,
			'reset_jobs' => $updated,
		]);
	}

	/**
	 * Enqueue global scanner script on all admin pages.
	 * This allows scanning to continue across page navigation.
	 */
	private function enqueue_global_scanner(): void {
		if (! current_user_can('manage_options')) {
			return;
		}

		// Get the correct REST API base URL
		$rest_url = get_rest_url();

		// Localize scripts with shared data (do this first before enqueueing)
		$data = [
			'apiUrl' => $rest_url . 'cleara11y/v1/',
			'ajaxUrl' => admin_url('admin-ajax.php'),
			'nonce' => wp_create_nonce('wp_rest'),
			'ajaxNonce' => wp_create_nonce('cleara11y-nonce'),
			'pluginUrl' => CLEARA11Y_PLUGIN_URL,
			'workerId' => sanitize_text_field(wp_unslash(is_scalar($_COOKIE['cleara11y_worker_id'] ?? null) ? $_COOKIE['cleara11y_worker_id'] : '')),
			'axeTags' => \ClearA11y\Services\Scan_Results_Processor::get_wcag_tags(
				(string) get_option('cleara11y_wcag_level', 'wcag21aa')
			),
		];

		// Enqueue toolbar styles
		wp_enqueue_style(
			'cleara11y-toolbar',
			CLEARA11Y_PLUGIN_URL . 'assets/css/toolbar.css',
			[],
			CLEARA11Y_VERSION
		);

		// Enqueue global scanner FIRST (it initializes cleara11yData)
		wp_enqueue_script(
			'cleara11y-global-scanner',
			CLEARA11Y_PLUGIN_URL . 'assets/js/global-admin-scanner.js',
			[],
			CLEARA11Y_VERSION,
			true
		);
		wp_localize_script('cleara11y-global-scanner', 'cleara11yData', $data);

		// Enqueue scan indicator SECOND (uses existing cleara11yData)
		wp_enqueue_script(
			'cleara11y-scan-indicator',
			CLEARA11Y_PLUGIN_URL . 'assets/js/scan-indicator.js',
			['cleara11y-global-scanner'], // Depend on global scanner
			CLEARA11Y_VERSION,
			true
		);
		// Don't re-localize - indicator uses the same cleara11yData
	}

	/**
	 * Add scan progress indicator to admin toolbar.
	 *
	 * @param \WP_Admin_Bar $wp_admin_bar WordPress admin bar instance.
	 */
	public function add_toolbar_indicator(\WP_Admin_Bar $wp_admin_bar): void {
		// Skip if we're currently scanning (admin bar is hidden)
		if (\ClearA11y\Frontend\Scanner::is_scanning()) {
			return;
		}

		// Only show for users with manage_options capability
		if (!current_user_can('manage_options')) {
			return;
		}

		// Get active scan
		global $wpdb;
		$scans_table = \ClearA11y\Database\Schema::get_table_name('scans');
		$jobs_table = \ClearA11y\Database\Schema::get_table_name('scan_jobs');

		// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state; Schema-owned identifiers and fixed SQL fragments; variable values are prepared separately.
		$scan = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM `{$scans_table}`
				WHERE status = 'in_progress'
				ORDER BY id DESC
				LIMIT 1"
			)
		);
		// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		if (!$scan) {
			// No active scan, show a simple "ClearA11y" menu item
			$wp_admin_bar->add_node([
				'id'    => 'cleara11y-toolbar',
				'title' => '<span class="ab-icon" aria-hidden="true"></span><span class="ab-label">ClearA11y</span>',
				'href'  => admin_url('admin.php?page=cleara11y'),
				'meta'  => [
					'title' => __('Accessibility Scanner', 'cleara11y'),
				],
			]);
			return;
		}

		// Get job statistics for this scan
		$stats = \ClearA11y\Database\Job_Repository::get_stats_by_scan((int) $scan->id);
		$total = $stats['pending'] + $stats['active'] + $stats['completed'] + $stats['failed'];
		$completed = $stats['completed'];
		$progress = $total > 0 ? round(($completed / $total) * 100) : 0;

		// Build title with progress indicator
		$title = sprintf(
			'<span class="ab-icon" aria-hidden="true"></span>
			<span class="ab-label">ClearA11y</span>
				<span class="cleara11y-progress-text">%d/%d</span>
			</span>',
			esc_attr($scan->id),
			esc_attr($progress),
			esc_attr($progress),
			esc_html($completed),
			esc_html($total),
			esc_html($progress)
		);

		// Add toolbar menu with scan progress
		$wp_admin_bar->add_node([
			'id'    => 'cleara11y-toolbar',
			'title' => $title,
			'href'  => admin_url('admin.php?page=cleara11y'),
			'meta'  => [
				/* translators: Placeholder is scan completion as a percentage. */
				'title' => sprintf(__('Accessibility Scan: %d%% complete', 'cleara11y'), $progress),
				'class' => 'cleara11y-scanning',
			],
		]);
	}

	/**
	 * Register admin menu.
	 */
	public function register_menu(): void {
		add_menu_page(
			__('ClearA11y', 'cleara11y'),
			__('ClearA11y', 'cleara11y'),
			'manage_options',
			'cleara11y',
			[Dashboard_Page::class, 'render'],
			'dashicons-universal-access-alt',
			30
		);

		add_submenu_page(
			'cleara11y',
			__('Dashboard', 'cleara11y'),
			__('Dashboard', 'cleara11y'),
			'manage_options',
			'cleara11y',
			[Dashboard_Page::class, 'render']
		);

		// Add Scans submenu page
		add_submenu_page(
			'cleara11y',
			__('Scans', 'cleara11y'),
			__('Scans', 'cleara11y'),
			'manage_options',
			'cleara11y-scans',
			[Scans_Page::class, 'render']
		);

		// Hidden scan detail page, accessible from Scans and dashboard links.
		add_submenu_page(
			null,
			__('Scan Details', 'cleara11y'),
			__('Scan Details', 'cleara11y'),
			'manage_options',
			'cleara11y-scan-detail',
			[Scan_Detail_Page::class, 'render']
		);

		// Add Issues List submenu page
		$issues_hook = add_submenu_page(
			'cleara11y',
			__('Issues', 'cleara11y'),
			__('Issues', 'cleara11y'),
			'manage_options',
			'cleara11y-issues',
			[Issues_List_Page::class, 'render']
		);
		add_action('load-' . $issues_hook, [$this, 'register_issues_screen_options']);

		// Add Exceptions submenu page
		add_submenu_page(
			'cleara11y',
			__('Exceptions', 'cleara11y'),
			__('Exceptions', 'cleara11y'),
			'manage_options',
			'cleara11y-exceptions',
			[Exceptions_Page::class, 'render']
		);

		// // Add Issue Types submenu page
		// add_submenu_page(
		// 	'cleara11y',
		// 	__('Issue Types', 'cleara11y'),
		// 	__('Issue Types', 'cleara11y'),
		// 	'manage_options',
		// 	'cleara11y-issue-types',
		// 	[Issue_Types_Page::class, 'render_page']
		// );

		// Add Issue Reference submenu page
		add_submenu_page(
			'cleara11y',
			__('Issue Reference', 'cleara11y'),
			__('Issue Reference', 'cleara11y'),
			'manage_options',
			'cleara11y-issue-reference',
			[Issue_Reference_Page::class, 'render_page']
		);

		// Add Settings submenu page
		add_submenu_page(
			'cleara11y',
			__('Settings', 'cleara11y'),
			__('Settings', 'cleara11y'),
			'manage_options',
			'cleara11y-settings',
			[Settings_Page::class, 'render']
		);

		// Add Debug Tools submenu page
		add_submenu_page(
			'cleara11y',
			__('Debug Tools', 'cleara11y'),
			__('Debug Tools', 'cleara11y'),
			'manage_options',
			'cleara11y-debug',
			[$this, 'render_debug_page']
		);
	}

	/**
	 * Register per-user display preferences for the Issues Explorer.
	 *
	 * @return void
	 */
	public function register_issues_screen_options(): void {
		add_screen_option(
			'per_page',
			[
				'label' => __('Issues per page', 'cleara11y'),
				'default' => 20,
				'option' => 'cleara11y_issues_per_page',
			]
		);

		add_filter('screen_settings', [$this, 'render_issues_screen_settings'], 10, 2);
	}

	/**
	 * Add Issues Explorer display preferences to WordPress Screen Options.
	 *
	 * @param string     $settings Existing Screen Options markup.
	 * @param \WP_Screen $screen Current screen.
	 * @return string
	 */
	public function render_issues_screen_settings(string $settings, \WP_Screen $screen): string {
		if ('cleara11y_page_cleara11y-issues' !== $screen->id) {
			return $settings;
		}

		$options = $this->get_issue_view_options();
		ob_start();
		?>
		<fieldset class="metabox-prefs cleara11y-issue-view-options">
			<legend><?php esc_html_e('Issue display', 'cleara11y'); ?></legend>
			<label>
				<input type="checkbox" data-cleara11y-view-option="show_selector" <?php checked($options['show_selector']); ?>>
				<?php esc_html_e('CSS selectors', 'cleara11y'); ?>
			</label>
			<label>
				<input type="checkbox" data-cleara11y-view-option="show_html" <?php checked($options['show_html']); ?>>
				<?php esc_html_e('HTML excerpts', 'cleara11y'); ?>
			</label>
			<label>
				<input type="checkbox" data-cleara11y-view-option="show_thumbnails" <?php checked($options['show_thumbnails']); ?>>
				<?php esc_html_e('Image thumbnails', 'cleara11y'); ?>
			</label>
			<p class="description">
				<?php esc_html_e('Changes save automatically for your account.', 'cleara11y'); ?>
				<span id="cleara11y-view-options-status" class="screen-reader-text" aria-live="polite"></span>
			</p>
		</fieldset>
		<?php

		return $settings . (string) ob_get_clean();
	}

	/**
	 * Get Issues Explorer display preferences for the current user.
	 *
	 * @return array<string, bool>
	 */
	private function get_issue_view_options(): array {
		$options = get_user_meta(get_current_user_id(), 'cleara11y_issue_view_options', true);
		$options = is_array($options) ? $options : [];

		$defaults = $this->get_issue_view_option_defaults();
		$options = array_merge($defaults, array_intersect_key($options, $defaults));

		return array_map(static fn($value): bool => (bool) $value, $options);
	}

	/**
	 * Get default Issues Explorer display preferences.
	 *
	 * @return array<string, bool>
	 */
	private function get_issue_view_option_defaults(): array {
		return [
			'show_selector' => false,
			'show_html' => false,
			'show_thumbnails' => false,
		];
	}

	/**
	 * Sanitize ClearA11y Screen Options before WordPress stores them.
	 *
	 * @param mixed  $screen_option Existing filtered value.
	 * @param string $option Screen option name.
	 * @param mixed  $value Submitted value.
	 * @return mixed
	 */
	public function save_screen_option($screen_option, string $option, $value) {
		if ('cleara11y_issues_per_page' !== $option) {
			return $screen_option;
		}

		return min(100, max(1, absint($value)));
	}

	/**
	 * Render debug tools page.
	 */
	public function render_debug_page(): void {
		if (! current_user_can('manage_options')) {
			wp_die(esc_html__('You do not have permission to perform this action.', 'cleara11y'));
		}

		// Handle test scan request - redirect to page with scan token
		if (isset($_POST['cleara11y_test_scan']) && check_admin_referer('cleara11y_test_scan')) {
			$post_id = absint(is_scalar($_POST['test_post_id'] ?? null) ? wp_unslash($_POST['test_post_id']) : 0);
			if ($post_id > 0) {
				// Generate a temporary scan token
				$token = \ClearA11y\Services\Scan_Token_Manager::generate_token($post_id, 'test');
				if (isset($token['error'])) {
					echo '<div class="notice notice-error"><p>Error: ' . esc_html($token['error']) . '</p></div>';
				} else {
					// Redirect to the page with the scan token (in foreground mode for testing)
					$scan_url = add_query_arg(
						['cleara11y_scan' => $token['token']],
						get_permalink($post_id)
					);
					echo '<p>Redirecting to scan page... <a href="' . esc_url($scan_url) . '">Click here if not redirected</a></p>';
					wp_register_script('cleara11y-debug-redirect', false, [], CLEARA11Y_VERSION, true);
					wp_enqueue_script('cleara11y-debug-redirect');
					wp_add_inline_script('cleara11y-debug-redirect', 'window.location.href = ' . wp_json_encode(esc_url_raw($scan_url), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) . ';');
					return;
				}
			}
		}

		// Check if reset form was submitted
		if (isset($_POST['cleara11y_reset_stuck']) && check_admin_referer('cleara11y_reset_stuck')) {
			$reset = \ClearA11y\Services\Scan_Orchestrator::reset_stuck_scans();

			echo '<div class="notice notice-success is-dismissible"><p>';
			echo esc_html(
				sprintf(
					/* translators: 1: Jobs reset, 2: Scan items reset, 3: Resumable scans. */
					__('Reset %1$d jobs and %2$d scan items across %3$d resumable scans.', 'cleara11y'),
					$reset['jobs'],
					$reset['items'],
					$reset['scans']
				)
			);
			echo '</p></div>';
		}

		// Get list of published pages/posts
		$post_types = get_post_types(['public' => true], 'objects');

		?>
		<div class="wrap">
			<h1><?php esc_html_e('ClearA11y Debug Tools', 'cleara11y'); ?></h1>

			<h2>Available Pages for Scanning</h2>
			<table class="wp-list-table widefat fixed striped">
				<thead>
					<tr>
						<th>ID</th>
						<th>Title</th>
						<th>Type</th>
						<th>URL</th>
						<th>Status</th>
					</tr>
				</thead>
				<tbody>
					<?php
					foreach ($post_types as $post_type) {
						$args = [
							'post_type' => $post_type->name,
							'post_status' => 'publish',
							'numberposts' => 50,
							'orderby' => 'title',
							'order' => 'ASC'
						];

						$posts = get_posts($args);

						foreach ($posts as $post) {
							$url = get_permalink($post->ID);
							$status = get_post_status($post->ID);
							?>
							<tr>
								<td><?php echo esc_html($post->ID); ?></td>
								<td><?php echo esc_html($post->post_title); ?></td>
								<td><?php echo esc_html($post_type->labels->singular_name); ?></td>
								<td><a href="<?php echo esc_url($url); ?>" target="_blank"><?php echo esc_html($url); ?></a></td>
								<td><?php echo esc_html($status); ?></td>
							</tr>
							<?php
						}
					}
					?>
				</tbody>
			</table>

			<h2>Reset Stuck Scans</h2>
			<p>Use this tool to release active job leases and return interrupted work to the pending queue.</p>
			<form method="post">
				<?php wp_nonce_field('cleara11y_reset_stuck'); ?>
				<input type="submit" name="cleara11y_reset_stuck" class="button button-primary" value="Reset Stuck Scans">
			</form>

			<h2>Test Scanner</h2>
			<p>Generate a test scan token to manually test the scanner. The page will open in a new tab with the scanner enabled.</p>
			<form method="post" target="_blank">
				<?php wp_nonce_field('cleara11y_test_scan'); ?>
				<select name="test_post_id" class="regular-text">
					<option value="">Select a page to scan...</option>
					<?php
					foreach ($post_types as $post_type) {
						$posts = get_posts([
							'post_type' => $post_type->name,
							'post_status' => 'publish',
							'numberposts' => 20,
							'orderby' => 'title',
							'order' => 'ASC'
						]);
						foreach ($posts as $post) {
							echo '<option value="' . esc_attr($post->ID) . '">' . esc_html($post_type->labels->singular_name . ': ' . $post->post_title) . '</option>';
						}
					}
					?>
				</select>
				<input type="submit" name="cleara11y_test_scan" class="button" value="Test Scan in New Tab">
				<span style="margin-left: 10px; color: #646970;">(Look for the scanner overlay when page loads)</span>
			</form>

			<h2>Queue Status</h2>
			<?php
			global $wpdb;
			$items_table = \ClearA11y\Database\Schema::get_table_name('scan_items');
			$scans_table = \ClearA11y\Database\Schema::get_table_name('scans');

			$pending = $wpdb->get_var("SELECT COUNT(*) FROM `{$items_table}` WHERE status = 'pending'"); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state; Schema-owned identifiers and fixed SQL fragments; variable values are prepared separately.
			$in_progress = $wpdb->get_var("SELECT COUNT(*) FROM `{$items_table}` WHERE status = 'in_progress'"); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state; Schema-owned identifiers and fixed SQL fragments; variable values are prepared separately.
			$completed = $wpdb->get_var("SELECT COUNT(*) FROM `{$items_table}` WHERE status = 'completed'"); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state; Schema-owned identifiers and fixed SQL fragments; variable values are prepared separately.
			$failed = $wpdb->get_var("SELECT COUNT(*) FROM `{$items_table}` WHERE status = 'failed'"); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state; Schema-owned identifiers and fixed SQL fragments; variable values are prepared separately.

			echo '<ul>';
			echo '<li>Pending: <strong>' . intval($pending) . '</strong></li>';
			echo '<li>In Progress: <strong>' . intval($in_progress) . '</strong></li>';
			echo '<li>Completed: <strong>' . intval($completed) . '</strong></li>';
			echo '<li>Failed: <strong>' . intval($failed) . '</strong></li>';
			echo '</ul>';

			// Show recent scan items with details
			// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Live scan/exception state in custom tables; caching can return stale worker or suppression state; Schema-owned identifiers and fixed SQL fragments; variable values are prepared separately.
			$recent_items = $wpdb->get_results(
				"SELECT id, post_title, status, created_at, error_message FROM `{$items_table}` ORDER BY created_at DESC LIMIT 5"
			);
			// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			if ($recent_items) {
				echo '<h4>Recent Scan Items:</h4>';
				echo '<table class="wp-list-table widefat fixed striped" style="margin-top: 10px;">';
				echo '<thead><tr><th>ID</th><th>Page</th><th>Status</th><th>Error</th><th>Created</th></tr></thead>';
				echo '<tbody>';
				foreach ($recent_items as $item) {
					echo '<tr>';
					echo '<td>' . esc_html($item->id) . '</td>';
					echo '<td>' . esc_html($item->post_title ?: 'N/A') . '</td>';
					echo '<td>' . esc_html($item->status) . '</td>';
					echo '<td>' . esc_html($item->error_message ?: '') . '</td>';
					echo '<td>' . esc_html($item->created_at) . '</td>';
					echo '</tr>';
				}
				echo '</tbody></table>';
			}
			?>
		</div>
		<?php
	}

	/**
	 * Enqueue admin assets.
	 *
	 * @param string $hook_suffix Current admin page.
	 */
	public function enqueue_assets(string $hook_suffix): void {
		// Always load global scanner on ALL admin pages for scan continuation
		$this->enqueue_global_scanner();

		// Only load page-specific assets on our pages
		if (strpos($hook_suffix, 'cleara11y') === false) {
			return;
		}

		// Enqueue dashboard CSS
		wp_enqueue_style(
			'cleara11y-dashboard',
			CLEARA11Y_PLUGIN_URL . 'assets/css/dashboard.css',
			[],
			CLEARA11Y_VERSION
		);

		foreach (['settings', 'issue-types', 'issue-reference'] as $page) {
			if ('cleara11y_page_cleara11y-' . $page === $hook_suffix) {
				wp_enqueue_style('cleara11y-' . $page, CLEARA11Y_PLUGIN_URL . 'assets/css/' . $page . '.css', [], CLEARA11Y_VERSION);
			}
		}
		if ('cleara11y_page_cleara11y-settings' === $hook_suffix) {
			wp_enqueue_script('cleara11y-settings', CLEARA11Y_PLUGIN_URL . 'assets/js/settings.js', [], CLEARA11Y_VERSION, true);
			wp_localize_script('cleara11y-settings', 'cleara11ySettings', [
				'confirmClear' => __('Are you sure you want to clear the scan database? This action cannot be undone and will delete all scan data.', 'cleara11y'),
				'confirmFinal' => __('This is your last chance! Click OK to permanently delete all scan data, or Cancel to keep your data.', 'cleara11y'),
			]);
		}

		// Get the correct REST API base URL
		$rest_url = get_rest_url();

		// Check which page we're on
		$is_issues_page = ($hook_suffix === 'cleara11y_page_cleara11y-issues');
		$is_issue_types_page = ($hook_suffix === 'cleara11y_page_cleara11y-issue-types');
		$is_issue_reference_page = ($hook_suffix === 'cleara11y_page_cleara11y-issue-reference');
		$is_exceptions_page = ($hook_suffix === 'cleara11y_page_cleara11y-exceptions');

		// Enqueue the appropriate JavaScript
		if ($is_issues_page) {
			$issues_per_page = absint(get_user_option('cleara11y_issues_per_page'));
			$issues_per_page = min(100, max(1, $issues_per_page ?: 20));
			$issue_view_options = $this->get_issue_view_options();
			$issues_style_version = CLEARA11Y_VERSION;
			$issues_query_version = CLEARA11Y_VERSION;
			$issues_script_version = CLEARA11Y_VERSION;
			if ('local' === wp_get_environment_type()) {
				$issues_style_version = (string) filemtime(CLEARA11Y_PLUGIN_DIR . 'assets/css/issues-explorer.css');
				$issues_query_version = (string) filemtime(CLEARA11Y_PLUGIN_DIR . 'assets/js/issues-explorer-query.js');
				$issues_script_version = (string) filemtime(CLEARA11Y_PLUGIN_DIR . 'assets/js/issues-list.js');
			}

			wp_enqueue_style(
				'cleara11y-issues-explorer',
				CLEARA11Y_PLUGIN_URL . 'assets/css/issues-explorer.css',
				[],
				$issues_style_version
			);

			// Enqueue toast CSS for notifications
			wp_enqueue_style(
				'cleara11y-toast',
				CLEARA11Y_PLUGIN_URL . 'assets/css/toast.css',
				[],
				CLEARA11Y_VERSION
			);

			// Enqueue ignores page CSS for wizard
			wp_enqueue_style(
				'cleara11y-exceptions-page',
				CLEARA11Y_PLUGIN_URL . 'assets/css/exceptions-page.css',
				[],
				'local' === wp_get_environment_type()
					? (string) filemtime(CLEARA11Y_PLUGIN_DIR . 'assets/css/exceptions-page.css')
					: CLEARA11Y_VERSION
			);

			// Enqueue jQuery (required for ignores page wizard)
			wp_enqueue_script('jquery');

			// Enqueue ignores page script for wizard functionality
			wp_enqueue_script(
				'cleara11y-exceptions-page',
				CLEARA11Y_PLUGIN_URL . 'assets/js/exceptions-page.js',
				['jquery'],
				CLEARA11Y_VERSION,
				true
			);

			// Localize ignores page script
			wp_localize_script('cleara11y-exceptions-page', 'cleara11yExceptions', [
				'apiUrl' => $rest_url . 'cleara11y/v1/exceptions',
				'nonce' => wp_create_nonce('wp_rest'),
				'strings' => Exceptions_Page::get_script_strings(),
			]);

			wp_enqueue_script(
				'cleara11y-issues-query',
				CLEARA11Y_PLUGIN_URL . 'assets/js/issues-explorer-query.js',
				[],
				$issues_query_version,
				true
			);

			// Enqueue issues explorer JavaScript.
			wp_enqueue_script(
				'cleara11y-issues-list',
				CLEARA11Y_PLUGIN_URL . 'assets/js/issues-list.js',
				['cleara11y-issues-query'],
				$issues_script_version,
				true
			);

			// Localize issues list script
			wp_localize_script('cleara11y-issues-list', 'cleara11yData', [
				'apiUrl' => $rest_url . 'cleara11y/v1/',
				'ajaxUrl' => admin_url('admin-ajax.php'),
				'nonce' => wp_create_nonce('wp_rest'),
				'viewOptionsNonce' => wp_create_nonce('cleara11y_issue_view_options'),
				'pluginUrl' => CLEARA11Y_PLUGIN_URL,
				'perPage' => $issues_per_page,
				'viewOptions' => $issue_view_options,
				'strings' => [
					'loadingOccurrences' => __('Loading issue occurrences…', 'cleara11y'),
					'activeTitle' => __('Active accessibility issues', 'cleara11y'),
					'noIssues' => __('No active issues exist in this scope.', 'cleara11y'),
					'noFilteredIssues' => __('No issues match the current filters.', 'cleara11y'),
					'noScanIssues' => __('This scan did not report any issues matching this scope.', 'cleara11y'),
					'error' => __('Error loading issues.', 'cleara11y'),
				],
			]);
		} elseif ($is_issue_types_page) {
			// Enqueue issue types JavaScript
			wp_enqueue_script(
				'cleara11y-issue-types',
				CLEARA11Y_PLUGIN_URL . 'assets/js/issue-types.js',
				[],
				CLEARA11Y_VERSION,
				true
			);

			// Localize issue types script
			wp_localize_script('cleara11y-issue-types', 'cleara11yData', [
				'apiUrl' => $rest_url . 'cleara11y/v1/',
				'nonce' => wp_create_nonce('wp_rest'),
				'pluginUrl' => CLEARA11Y_PLUGIN_URL,
				'strings' => [
					'loading' => __('Loading...', 'cleara11y'),
					'noIssues' => __('No issues found.', 'cleara11y'),
					'error' => __('Error loading issue types.', 'cleara11y'),
					'confirmGlobalIgnore' => __('Are you sure you want to mark this issue type as a global exception?', 'cleara11y'),
					'confirmGlobalUnignore' => __('Are you sure you want to remove the global exception for this issue type?', 'cleara11y'),
				],
			]);
		} elseif ($is_issue_reference_page) {
			wp_enqueue_script('axe-core', CLEARA11Y_PLUGIN_URL . 'assets/js/axe.min.js', [], '4.10.2', true);
			// Enqueue issue reference JavaScript
			wp_enqueue_script(
				'cleara11y-issue-reference',
				CLEARA11Y_PLUGIN_URL . 'assets/js/issue-reference.js',
				['axe-core'],
				CLEARA11Y_VERSION,
				true
			);

			// Localize issue reference script
			wp_localize_script('cleara11y-issue-reference', 'cleara11yData', [
				'apiUrl' => $rest_url . 'cleara11y/v1/',
				'nonce' => wp_create_nonce('wp_rest'),
				'pluginUrl' => CLEARA11Y_PLUGIN_URL,
				'strings' => [
					'loading' => __('Loading...', 'cleara11y'),
					'noIssues' => __('No rules found.', 'cleara11y'),
					'error' => __('Error loading rules.', 'cleara11y'),
				],
				// Include severity mapping for all axe-core rules
				'severityMap' => \ClearA11y\Services\Rule_Severity_Map::get_severity_map(),
			]);
		} elseif ($is_exceptions_page) {
			// Enqueue ignores page JavaScript
			wp_enqueue_script(
				'cleara11y-exceptions-page',
				CLEARA11Y_PLUGIN_URL . 'assets/js/exceptions-page.js',
				['jquery', 'wp-api'],
				CLEARA11Y_VERSION,
				true
			);

			// Localize ignores page script
			wp_localize_script('cleara11y-exceptions-page', 'cleara11yExceptions', [
				'apiUrl' => $rest_url . 'cleara11y/v1/exceptions',
				'nonce' => wp_create_nonce('wp_rest'),
				'strings' => Exceptions_Page::get_script_strings(),
			]);
		} else {
			// Enqueue scanner orchestrator first (loaded but not executed directly)
			wp_enqueue_script(
				'cleara11y-scanner-orchestrator',
				CLEARA11Y_PLUGIN_URL . 'assets/js/scanner-orchestrator.js',
				[],
				CLEARA11Y_VERSION,
				true
			);

			// Enqueue dashboard JavaScript (depends on orchestrator)
			wp_enqueue_script(
				'cleara11y-dashboard',
				CLEARA11Y_PLUGIN_URL . 'assets/js/dashboard.js',
				['cleara11y-scanner-orchestrator'],
				CLEARA11Y_VERSION,
				true
			);

			// Localize dashboard script
			wp_localize_script('cleara11y-dashboard', 'cleara11yData', [
			'apiUrl' => $rest_url . 'cleara11y/v1/',
			'wpApiUrl' => $rest_url . 'wp/v2/',
			'ajaxUrl' => admin_url('admin-ajax.php'),
			'nonce' => wp_create_nonce('wp_rest'),
			'ajaxNonce' => wp_create_nonce('cleara11y-nonce'),
			'pluginUrl' => CLEARA11Y_PLUGIN_URL,
			'axeTags' => \ClearA11y\Services\Scan_Results_Processor::get_wcag_tags(
				(string) get_option('cleara11y_wcag_level', 'wcag21aa')
			),
			'strings' => [
				'scanInProgress' => __('Scan in progress...', 'cleara11y'),
				'scanComplete' => __('Scan complete!', 'cleara11y'),
				'scanFailed' => __('Scan failed.', 'cleara11y'),
				'loading' => __('Loading...', 'cleara11y'),
				'noIssues' => __('No accessibility issues found!', 'cleara11y'),
			],
			// Debug info
			'debug' => [
				'restUrl' => $rest_url,
				'siteUrl' => site_url(),
				'homeUrl' => home_url(),
			],
		]);
		}
	}
}
